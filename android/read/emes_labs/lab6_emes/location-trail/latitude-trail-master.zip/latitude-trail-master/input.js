window.latitudeJsonData = {
  "data": {
    "items": [
      {
         "timestampMs": 1341603938230,
         "latitude": 37.619065,
         "longitude": -122.3919863
      },
      {
         "timestampMs": 1341603818093,
         "latitude": 37.6182984,
         "longitude": -122.3923514
      },
      {
         "timestampMs": 1341603698076,
         "latitude": 37.6182868,
         "longitude": -122.3925354
      },
      {
         "timestampMs": 1341603277972,
         "latitude": 37.6190573,
         "longitude": -122.392011
      },
      {
         "timestampMs": 1341603098788,
         "latitude": 37.6182868,
         "longitude": -122.3925354
      },
      {
         "timestampMs": 1341602977848,
         "latitude": 37.6190573,
         "longitude": -122.392011
      },
      {
         "timestampMs": 1341602618566,
         "latitude": 37.6181879,
         "longitude": -122.3922855
      },
      {
         "timestampMs": 1341601131756,
         "latitude": 37.6183845,
         "longitude": -122.3924124
      },
      {
         "timestampMs": 1341601066130,
         "latitude": 37.6189752,
         "longitude": -122.3924657
      },
      {
         "timestampMs": 1341601015143,
         "latitude": 37.6191958,
         "longitude": -122.3927534
      },
      {
         "timestampMs": 1341601010511,
         "latitude": 37.6183513,
         "longitude": -122.3923757
      },
      {
         "timestampMs": 1341601007158,
         "latitude": 37.6184882,
         "longitude": -122.3924806
      },
      {
         "timestampMs": 1341600948135,
         "latitude": 37.6191644,
         "longitude": -122.3926812
      },
      {
         "timestampMs": 1341600940163,
         "latitude": 37.6190569,
         "longitude": -122.3923993
      },
      {
         "timestampMs": 1341600932161,
         "latitude": 37.6186606,
         "longitude": -122.3919188
      },
      {
         "timestampMs": 1341600925235,
         "latitude": 37.6183735,
         "longitude": -122.3923719
      },
      {
         "timestampMs": 1341600822134,
         "latitude": 37.6188643,
         "longitude": -122.3923716
      },
      {
         "timestampMs": 1341600703432,
         "latitude": 37.618415,
         "longitude": -122.3924302
      },
      {
         "timestampMs": 1341600463437,
         "latitude": 37.6183107,
         "longitude": -122.3923226
      },
      {
         "timestampMs": 1341598295000,
         "latitude": 37.617112,
         "longitude": -122.383103
      },
      {
         "timestampMs": 1341597823614,
         "latitude": 37.6185211,
         "longitude": -122.3926052
      },
      {
         "timestampMs": 1341594092550,
         "latitude": 37.6867301,
         "longitude": -122.468268
      },
      {
         "timestampMs": 1341593974562,
         "latitude": 37.6985968,
         "longitude": -122.4705043
      },
      {
         "timestampMs": 1341593851669,
         "latitude": 37.7092193,
         "longitude": -122.4645028
      },
      {
         "timestampMs": 1341593791825,
         "latitude": 37.7109122,
         "longitude": -122.4592202
      },
      {
         "timestampMs": 1341593731809,
         "latitude": 37.7138565,
         "longitude": -122.4518807
      },
      {
         "timestampMs": 1341593527457,
         "latitude": 37.7323961,
         "longitude": -122.4350787
      },
      {
         "timestampMs": 1341593505475,
         "latitude": 37.7216431,
         "longitude": -122.4463325
      },
      {
         "timestampMs": 1341592953381,
         "latitude": 37.7803053,
         "longitude": -122.4126862
      },
      {
         "timestampMs": 1341592844021,
         "latitude": 37.7804361,
         "longitude": -122.4127514
      },
      {
         "timestampMs": 1341592785274,
         "latitude": 37.7806295,
         "longitude": -122.4122188
      },
      {
         "timestampMs": 1341592653215,
         "latitude": 37.7807149,
         "longitude": -122.4121767
      },
      {
         "timestampMs": 1341591680051,
         "latitude": 37.7811099,
         "longitude": -122.4121874
      },
      {
         "timestampMs": 1341591559947,
         "latitude": 37.7814967,
         "longitude": -122.4115671
      },
      {
         "timestampMs": 1341591439738,
         "latitude": 37.7823595,
         "longitude": -122.4098861
      },
      {
         "timestampMs": 1341591413342,
         "latitude": 37.7813794,
         "longitude": -122.4126666
      },
      {
         "timestampMs": 1341591293927,
         "latitude": 37.7813794,
         "longitude": -122.4126666
      },
      {
         "timestampMs": 1341591234059,
         "latitude": 37.7813794,
         "longitude": -122.4126666
      },
      {
         "timestampMs": 1341590960376,
         "latitude": 37.7804401,
         "longitude": -122.4126348
      },
      {
         "timestampMs": 1341590660210,
         "latitude": 37.7796107,
         "longitude": -122.4188827
      },
      {
         "timestampMs": 1341590480108,
         "latitude": 37.7805149,
         "longitude": -122.4164776
      },
      {
         "timestampMs": 1341590420095,
         "latitude": 37.7808427,
         "longitude": -122.4155924
      },
      {
         "timestampMs": 1341590273793,
         "latitude": 37.7813794,
         "longitude": -122.4126666
      },
      {
         "timestampMs": 1341590179054,
         "latitude": 37.7806342,
         "longitude": -122.4130123
      },
      {
         "timestampMs": 1341590059946,
         "latitude": 37.7807502,
         "longitude": -122.4121019
      },
      {
         "timestampMs": 1341589038456,
         "latitude": 37.7814803,
         "longitude": -122.4123454
      },
      {
         "timestampMs": 1341588979304,
         "latitude": 37.7814803,
         "longitude": -122.4123454
      },
      {
         "timestampMs": 1341586670997,
         "latitude": 37.7813794,
         "longitude": -122.4126666
      },
      {
         "timestampMs": 1341586609991,
         "latitude": 37.7813794,
         "longitude": -122.4126666
      },
      {
         "timestampMs": 1341585378278,
         "latitude": 37.7814803,
         "longitude": -122.4123454
      },
      {
         "timestampMs": 1341583009567,
         "latitude": 37.7813794,
         "longitude": -122.4126666
      },
      {
         "timestampMs": 1341582136355,
         "latitude": 37.7814077,
         "longitude": -122.4123527
      },
      {
         "timestampMs": 1341582077206,
         "latitude": 37.7814077,
         "longitude": -122.4123527
      },
      {
         "timestampMs": 1341581609187,
         "latitude": 37.7813794,
         "longitude": -122.4126666
      },
      {
         "timestampMs": 1341578476489,
         "latitude": 37.7814077,
         "longitude": -122.4123527
      },
      {
         "timestampMs": 1341577816228,
         "latitude": 37.7814302,
         "longitude": -122.4124406
      },
      {
         "timestampMs": 1341577552095,
         "latitude": 37.7813794,
         "longitude": -122.4126666
      },
      {
         "timestampMs": 1341577011112,
         "latitude": 37.7813794,
         "longitude": -122.4126666
      },
      {
         "timestampMs": 1341576051614,
         "latitude": 37.7813794,
         "longitude": -122.4126666
      },
      {
         "timestampMs": 1341575930133,
         "latitude": 37.7813794,
         "longitude": -122.4126666
      },
      {
         "timestampMs": 1341574215192,
         "latitude": 37.7814302,
         "longitude": -122.4124406
      },
      {
         "timestampMs": 1341573134929,
         "latitude": 37.7814302,
         "longitude": -122.4124406
      },
      {
         "timestampMs": 1341572954788,
         "latitude": 37.7814302,
         "longitude": -122.4124406
      },
      {
         "timestampMs": 1341572329759,
         "latitude": 37.7813794,
         "longitude": -122.4126666
      },
      {
         "timestampMs": 1341571908735,
         "latitude": 37.7813794,
         "longitude": -122.4126666
      },
      {
         "timestampMs": 1341571849703,
         "latitude": 37.7813794,
         "longitude": -122.4126666
      },
      {
         "timestampMs": 1341569348780,
         "latitude": 37.7814302,
         "longitude": -122.4124406
      },
      {
         "timestampMs": 1341568269395,
         "latitude": 37.7814179,
         "longitude": -122.412432
      },
      {
         "timestampMs": 1341568189956,
         "latitude": 37.7813794,
         "longitude": -122.4126666
      },
      {
         "timestampMs": 1341568149336,
         "latitude": 37.7814179,
         "longitude": -122.412432
      },
      {
         "timestampMs": 1341567718868,
         "latitude": 37.7814179,
         "longitude": -122.412432
      },
      {
         "timestampMs": 1341567378921,
         "latitude": 37.7813794,
         "longitude": -122.4126666
      },
      {
         "timestampMs": 1341567077961,
         "latitude": 37.7813794,
         "longitude": -122.4126666
      },
      {
         "timestampMs": 1341566717843,
         "latitude": 37.7813794,
         "longitude": -122.4126666
      },
      {
         "timestampMs": 1341564117305,
         "latitude": 37.7814179,
         "longitude": -122.412432
      },
      {
         "timestampMs": 1341564057288,
         "latitude": 37.7814179,
         "longitude": -122.412432
      },
      {
         "timestampMs": 1341562935850,
         "latitude": 37.7813794,
         "longitude": -122.4126666
      },
      {
         "timestampMs": 1341562816623,
         "latitude": 37.7813794,
         "longitude": -122.4126666
      },
      {
         "timestampMs": 1341562216061,
         "latitude": 37.7813794,
         "longitude": -122.4126666
      },
      {
         "timestampMs": 1341561015754,
         "latitude": 37.7813794,
         "longitude": -122.4126666
      },
      {
         "timestampMs": 1341560954858,
         "latitude": 37.7813794,
         "longitude": -122.4126666
      },
      {
         "timestampMs": 1341560456398,
         "latitude": 37.7814179,
         "longitude": -122.412432
      },
      {
         "timestampMs": 1341560115664,
         "latitude": 37.7813794,
         "longitude": -122.4126666
      },
      {
         "timestampMs": 1341559934506,
         "latitude": 37.7813794,
         "longitude": -122.4126666
      },
      {
         "timestampMs": 1341556855071,
         "latitude": 37.7814179,
         "longitude": -122.412432
      },
      {
         "timestampMs": 1341555883367,
         "latitude": 37.7813794,
         "longitude": -122.4126666
      },
      {
         "timestampMs": 1341555294696,
         "latitude": 37.7814413,
         "longitude": -122.4124201
      },
      {
         "timestampMs": 1341555234704,
         "latitude": 37.7814413,
         "longitude": -122.4124201
      },
      {
         "timestampMs": 1341555173627,
         "latitude": 37.7814413,
         "longitude": -122.4124201
      },
      {
         "timestampMs": 1341555114476,
         "latitude": 37.7814413,
         "longitude": -122.4124201
      },
      {
         "timestampMs": 1341551512976,
         "latitude": 37.7814413,
         "longitude": -122.4124201
      },
      {
         "timestampMs": 1341550443307,
         "latitude": 37.7814217,
         "longitude": -122.4122507
      },
      {
         "timestampMs": 1341546842820,
         "latitude": 37.7813856,
         "longitude": -122.4116568
      },
      {
         "timestampMs": 1341546422739,
         "latitude": 37.7813856,
         "longitude": -122.4116568
      },
      {
         "timestampMs": 1341546363600,
         "latitude": 37.7813508,
         "longitude": -122.4123879
      },
      {
         "timestampMs": 1341544993644,
         "latitude": 37.7807743,
         "longitude": -122.4121215
      },
      {
         "timestampMs": 1341543543094,
         "latitude": 37.7807522,
         "longitude": -122.4121345
      },
      {
         "timestampMs": 1341541380154,
         "latitude": 37.7807669,
         "longitude": -122.4121515
      },
      {
         "timestampMs": 1341541306941,
         "latitude": 37.780759,
         "longitude": -122.4121417
      },
      {
         "timestampMs": 1341540664386,
         "latitude": 37.7814225,
         "longitude": -122.412371
      },
      {
         "timestampMs": 1341540541987,
         "latitude": 37.7813856,
         "longitude": -122.4116568
      },
      {
         "timestampMs": 1341540362861,
         "latitude": 37.7814652,
         "longitude": -122.4116514
      },
      {
         "timestampMs": 1341540244067,
         "latitude": 37.7825727,
         "longitude": -122.4097479
      },
      {
         "timestampMs": 1341540241550,
         "latitude": 37.7837014,
         "longitude": -122.4088388
      },
      {
         "timestampMs": 1341540004515,
         "latitude": 37.7843222,
         "longitude": -122.4080028
      },
      {
         "timestampMs": 1341539925164,
         "latitude": 37.7814322,
         "longitude": -122.4123724
      },
      {
         "timestampMs": 1341539581190,
         "latitude": 37.7859149,
         "longitude": -122.4082215
      },
      {
         "timestampMs": 1341538921077,
         "latitude": 37.786991,
         "longitude": -122.4081942
      },
      {
         "timestampMs": 1341538561048,
         "latitude": 37.7873959,
         "longitude": -122.4081589
      },
      {
         "timestampMs": 1341536864687,
         "latitude": 37.7814322,
         "longitude": -122.4123724
      },
      {
         "timestampMs": 1341536804672,
         "latitude": 37.7814322,
         "longitude": -122.4123724
      },
      {
         "timestampMs": 1341536099925,
         "latitude": 37.787462,
         "longitude": -122.408565
      },
      {
         "timestampMs": 1341535682945,
         "latitude": 37.7872768,
         "longitude": -122.4094521
      },
      {
         "timestampMs": 1341535501534,
         "latitude": 37.7875198,
         "longitude": -122.4080975
      },
      {
         "timestampMs": 1341535262467,
         "latitude": 37.7864628,
         "longitude": -122.4080271
      },
      {
         "timestampMs": 1341535202424,
         "latitude": 37.7860352,
         "longitude": -122.4082508
      },
      {
         "timestampMs": 1341535082264,
         "latitude": 37.7854579,
         "longitude": -122.4079809
      },
      {
         "timestampMs": 1341535079716,
         "latitude": 37.785011,
         "longitude": -122.4082723
      },
      {
         "timestampMs": 1341534841783,
         "latitude": 37.7847494,
         "longitude": -122.4073325
      },
      {
         "timestampMs": 1341534781727,
         "latitude": 37.7848052,
         "longitude": -122.4073989
      },
      {
         "timestampMs": 1341534659497,
         "latitude": 37.7822677,
         "longitude": -122.410265
      },
      {
         "timestampMs": 1341534599435,
         "latitude": 37.7814783,
         "longitude": -122.4114055
      },
      {
         "timestampMs": 1341534421909,
         "latitude": 37.7808374,
         "longitude": -122.4135195
      },
      {
         "timestampMs": 1341534301239,
         "latitude": 37.7806397,
         "longitude": -122.4161602
      },
      {
         "timestampMs": 1341534239321,
         "latitude": 37.7795008,
         "longitude": -122.4190004
      },
      {
         "timestampMs": 1341534179286,
         "latitude": 37.7802361,
         "longitude": -122.4203798
      },
      {
         "timestampMs": 1341534119261,
         "latitude": 37.7794231,
         "longitude": -122.4217019
      },
      {
         "timestampMs": 1341534064518,
         "latitude": 37.7791778,
         "longitude": -122.4225253
      },
      {
         "timestampMs": 1341533941483,
         "latitude": 37.7789168,
         "longitude": -122.4288387
      },
      {
         "timestampMs": 1341533825101,
         "latitude": 37.7776812,
         "longitude": -122.4384124
      },
      {
         "timestampMs": 1341533759159,
         "latitude": 37.777233,
         "longitude": -122.4429271
      },
      {
         "timestampMs": 1341533641690,
         "latitude": 37.7766176,
         "longitude": -122.4444607
      },
      {
         "timestampMs": 1341533580774,
         "latitude": 37.7757948,
         "longitude": -122.4470781
      },
      {
         "timestampMs": 1341533519118,
         "latitude": 37.775052,
         "longitude": -122.453166
      },
      {
         "timestampMs": 1341533341577,
         "latitude": 37.7743169,
         "longitude": -122.4582247
      },
      {
         "timestampMs": 1341533224413,
         "latitude": 37.7733654,
         "longitude": -122.4651991
      },
      {
         "timestampMs": 1341533161749,
         "latitude": 37.773384,
         "longitude": -122.466222
      },
      {
         "timestampMs": 1341532922130,
         "latitude": 37.7733637,
         "longitude": -122.4724902
      },
      {
         "timestampMs": 1341532801746,
         "latitude": 37.7779511,
         "longitude": -122.4840125
      },
      {
         "timestampMs": 1341531959568,
         "latitude": 37.770395,
         "longitude": -122.473287
      },
      {
         "timestampMs": 1341531719151,
         "latitude": 37.77388,
         "longitude": -122.465922
      },
      {
         "timestampMs": 1341531542286,
         "latitude": 37.7685178,
         "longitude": -122.4539171
      },
      {
         "timestampMs": 1341531302277,
         "latitude": 37.765589,
         "longitude": -122.474596
      },
      {
         "timestampMs": 1341531239510,
         "latitude": 37.767909,
         "longitude": -122.478151
      },
      {
         "timestampMs": 1341530936935,
         "latitude": 37.7686984,
         "longitude": -122.4545243
      },
      {
         "timestampMs": 1341530878795,
         "latitude": 37.774493,
         "longitude": -122.471376
      },
      {
         "timestampMs": 1341530820111,
         "latitude": 37.7844501,
         "longitude": -122.471937
      },
      {
         "timestampMs": 1341530681517,
         "latitude": 37.7814312,
         "longitude": -122.4123712
      },
      {
         "timestampMs": 1341530458845,
         "latitude": 37.770819,
         "longitude": -122.47682
      },
      {
         "timestampMs": 1341529861276,
         "latitude": 37.7681733,
         "longitude": -122.4662638
      },
      {
         "timestampMs": 1341529319305,
         "latitude": 37.7724878,
         "longitude": -122.4843419
      },
      {
         "timestampMs": 1341529137621,
         "latitude": 37.7724287,
         "longitude": -122.4858748
      },
      {
         "timestampMs": 1341529075763,
         "latitude": 37.7723913,
         "longitude": -122.4872697
      },
      {
         "timestampMs": 1341528956161,
         "latitude": 37.772341,
         "longitude": -122.4890378
      },
      {
         "timestampMs": 1341528778943,
         "latitude": 37.7722418,
         "longitude": -122.4912782
      },
      {
         "timestampMs": 1341528595219,
         "latitude": 37.7720765,
         "longitude": -122.4936157
      },
      {
         "timestampMs": 1341528535211,
         "latitude": 37.7719811,
         "longitude": -122.4948128
      },
      {
         "timestampMs": 1341528018911,
         "latitude": 37.7814312,
         "longitude": -122.4123712
      },
      {
         "timestampMs": 1341527396899,
         "latitude": 37.77187,
         "longitude": -122.4948697
      },
      {
         "timestampMs": 1341526856667,
         "latitude": 37.7719781,
         "longitude": -122.4956587
      },
      {
         "timestampMs": 1341526439848,
         "latitude": 37.7728057,
         "longitude": -122.4954242
      },
      {
         "timestampMs": 1341526137974,
         "latitude": 37.771928,
         "longitude": -122.4953084
      },
      {
         "timestampMs": 1341525917898,
         "latitude": 37.7814312,
         "longitude": -122.4123712
      },
      {
         "timestampMs": 1341525857977,
         "latitude": 37.7814312,
         "longitude": -122.4123712
      },
      {
         "timestampMs": 1341525797036,
         "latitude": 37.7814312,
         "longitude": -122.4123712
      },
      {
         "timestampMs": 1341522134809,
         "latitude": 37.7814312,
         "longitude": -122.4123712
      },
      {
         "timestampMs": 1341521294940,
         "latitude": 37.7814361,
         "longitude": -122.4123724
      },
      {
         "timestampMs": 1341520933964,
         "latitude": 37.7814361,
         "longitude": -122.4123724
      },
      {
         "timestampMs": 1341518476000,
         "latitude": 37.732127,
         "longitude": -122.504059
      },
      {
         "timestampMs": 1341518232455,
         "latitude": 37.733814,
         "longitude": -122.5047254
      },
      {
         "timestampMs": 1341517331575,
         "latitude": 37.7814361,
         "longitude": -122.4123724
      },
      {
         "timestampMs": 1341513832560,
         "latitude": 37.7814317,
         "longitude": -122.4124607
      },
      {
         "timestampMs": 1341510110655,
         "latitude": 37.7814317,
         "longitude": -122.4124607
      },
      {
         "timestampMs": 1341507889928,
         "latitude": 37.7815447,
         "longitude": -122.4128322
      },
      {
         "timestampMs": 1341507290074,
         "latitude": 37.7815447,
         "longitude": -122.4128322
      },
      {
         "timestampMs": 1341507020615,
         "latitude": 37.7432112,
         "longitude": -122.4730391
      },
      {
         "timestampMs": 1341506963185,
         "latitude": 37.7430098,
         "longitude": -122.4720479
      },
      {
         "timestampMs": 1341506903041,
         "latitude": 37.741512,
         "longitude": -122.4708192
      },
      {
         "timestampMs": 1341505479382,
         "latitude": 37.7807525,
         "longitude": -122.4121048
      },
      {
         "timestampMs": 1341505069332,
         "latitude": 37.7814278,
         "longitude": -122.4124314
      },
      {
         "timestampMs": 1341504108945,
         "latitude": 37.7814439,
         "longitude": -122.412369
      },
      {
         "timestampMs": 1341504048919,
         "latitude": 37.7814439,
         "longitude": -122.412369
      },
      {
         "timestampMs": 1341503391361,
         "latitude": 37.7815447,
         "longitude": -122.4128322
      },
      {
         "timestampMs": 1341503387147,
         "latitude": 37.7815812,
         "longitude": -122.4127074
      },
      {
         "timestampMs": 1341500447794,
         "latitude": 37.7814439,
         "longitude": -122.412369
      },
      {
         "timestampMs": 1341497987129,
         "latitude": 37.7814439,
         "longitude": -122.412369
      },
      {
         "timestampMs": 1341497909826,
         "latitude": 37.7813252,
         "longitude": -122.4124417
      },
      {
         "timestampMs": 1341494377701,
         "latitude": 37.7814439,
         "longitude": -122.412369
      },
      {
         "timestampMs": 1341492937112,
         "latitude": 37.7814439,
         "longitude": -122.412369
      },
      {
         "timestampMs": 1341492757090,
         "latitude": 37.7814439,
         "longitude": -122.412369
      },
      {
         "timestampMs": 1341492637041,
         "latitude": 37.7814439,
         "longitude": -122.412369
      },
      {
         "timestampMs": 1341492577025,
         "latitude": 37.7814439,
         "longitude": -122.412369
      },
      {
         "timestampMs": 1341492517008,
         "latitude": 37.7814439,
         "longitude": -122.412369
      },
      {
         "timestampMs": 1341490714631,
         "latitude": 37.7813718,
         "longitude": -122.4124426
      },
      {
         "timestampMs": 1341488915744,
         "latitude": 37.7814439,
         "longitude": -122.412369
      },
      {
         "timestampMs": 1341488855733,
         "latitude": 37.7814439,
         "longitude": -122.412369
      },
      {
         "timestampMs": 1341488555685,
         "latitude": 37.7814439,
         "longitude": -122.412369
      },
      {
         "timestampMs": 1341488315532,
         "latitude": 37.7814439,
         "longitude": -122.412369
      },
      {
         "timestampMs": 1341485310089,
         "latitude": 37.7830171,
         "longitude": -122.4127121
      },
      {
         "timestampMs": 1341484714191,
         "latitude": 37.7814439,
         "longitude": -122.412369
      },
      {
         "timestampMs": 1341484534087,
         "latitude": 37.7814439,
         "longitude": -122.412369
      },
      {
         "timestampMs": 1341484474013,
         "latitude": 37.7814439,
         "longitude": -122.412369
      },
      {
         "timestampMs": 1341480872756,
         "latitude": 37.7814439,
         "longitude": -122.412369
      },
      {
         "timestampMs": 1341480156559,
         "latitude": 37.7810285,
         "longitude": -122.4118536
      },
      {
         "timestampMs": 1341472851097,
         "latitude": 37.7814395,
         "longitude": -122.4124004
      },
      {
         "timestampMs": 1341470974553,
         "latitude": 37.7813713,
         "longitude": -122.4124383
      },
      {
         "timestampMs": 1341470691694,
         "latitude": 37.7807643,
         "longitude": -122.4121476
      },
      {
         "timestampMs": 1341470631690,
         "latitude": 37.7807709,
         "longitude": -122.4121485
      },
      {
         "timestampMs": 1341467449500,
         "latitude": 37.7813991,
         "longitude": -122.4124114
      },
      {
         "timestampMs": 1341467246813,
         "latitude": 37.7819394,
         "longitude": -122.4134229
      },
      {
         "timestampMs": 1341467193679,
         "latitude": 37.7813712,
         "longitude": -122.4124394
      },
      {
         "timestampMs": 1341466430530,
         "latitude": 37.7807497,
         "longitude": -122.4121812
      },
      {
         "timestampMs": 1341466310101,
         "latitude": 37.779625,
         "longitude": -122.413417
      },
      {
         "timestampMs": 1341465469511,
         "latitude": 37.7935575,
         "longitude": -122.4213059
      },
      {
         "timestampMs": 1341465399790,
         "latitude": 37.7943992,
         "longitude": -122.4214306
      },
      {
         "timestampMs": 1341465374638,
         "latitude": 37.794963,
         "longitude": -122.4215347
      },
      {
         "timestampMs": 1341465356591,
         "latitude": 37.7958872,
         "longitude": -122.4216325
      },
      {
         "timestampMs": 1341465236304,
         "latitude": 37.7975656,
         "longitude": -122.4223038
      },
      {
         "timestampMs": 1341465176719,
         "latitude": 37.798544,
         "longitude": -122.4223279
      },
      {
         "timestampMs": 1341464450684,
         "latitude": 37.8038284,
         "longitude": -122.4232717
      },
      {
         "timestampMs": 1341464318202,
         "latitude": 37.8047838,
         "longitude": -122.4237599
      },
      {
         "timestampMs": 1341463104239,
         "latitude": 37.8072396,
         "longitude": -122.4200347
      },
      {
         "timestampMs": 1341463044224,
         "latitude": 37.8067003,
         "longitude": -122.4215304
      },
      {
         "timestampMs": 1341462804182,
         "latitude": 37.8068279,
         "longitude": -122.4196397
      },
      {
         "timestampMs": 1341461963863,
         "latitude": 37.8065997,
         "longitude": -122.4222009
      },
      {
         "timestampMs": 1341461663963,
         "latitude": 37.8072396,
         "longitude": -122.4200351
      },
      {
         "timestampMs": 1341461543378,
         "latitude": 37.8065998,
         "longitude": -122.4222002
      },
      {
         "timestampMs": 1341459656876,
         "latitude": 37.8068279,
         "longitude": -122.4196397
      },
      {
         "timestampMs": 1341459495249,
         "latitude": 37.8066408,
         "longitude": -122.4233821
      },
      {
         "timestampMs": 1341459427419,
         "latitude": 37.8065919,
         "longitude": -122.4233663
      },
      {
         "timestampMs": 1341459426032,
         "latitude": 37.8072393,
         "longitude": -122.4200342
      },
      {
         "timestampMs": 1341459358511,
         "latitude": 37.8071639,
         "longitude": -122.4234188
      },
      {
         "timestampMs": 1341459335520,
         "latitude": 37.8072393,
         "longitude": -122.4200342
      },
      {
         "timestampMs": 1341459272611,
         "latitude": 37.8065662,
         "longitude": -122.4234256
      },
      {
         "timestampMs": 1341459265098,
         "latitude": 37.8068279,
         "longitude": -122.4196397
      },
      {
         "timestampMs": 1341459063759,
         "latitude": 37.806566,
         "longitude": -122.4233226
      },
      {
         "timestampMs": 1341456793927,
         "latitude": 37.8072413,
         "longitude": -122.4200338
      },
      {
         "timestampMs": 1341455774594,
         "latitude": 37.8068279,
         "longitude": -122.4196397
      },
      {
         "timestampMs": 1341454932041,
         "latitude": 37.8065214,
         "longitude": -122.4231548
      },
      {
         "timestampMs": 1341454805000,
         "latitude": 37.808648,
         "longitude": -122.42427
      },
      {
         "timestampMs": 1341454693420,
         "latitude": 37.8072396,
         "longitude": -122.4200342
      },
      {
         "timestampMs": 1341454633447,
         "latitude": 37.8068279,
         "longitude": -122.4196397
      },
      {
         "timestampMs": 1341454480327,
         "latitude": 37.8066953,
         "longitude": -122.4236111
      },
      {
         "timestampMs": 1341454390898,
         "latitude": 37.8072413,
         "longitude": -122.4200338
      },
      {
         "timestampMs": 1341454330875,
         "latitude": 37.8068279,
         "longitude": -122.4196397
      },
      {
         "timestampMs": 1341454091751,
         "latitude": 37.8071261,
         "longitude": -122.420714
      },
      {
         "timestampMs": 1341453430715,
         "latitude": 37.8060111,
         "longitude": -122.422512
      },
      {
         "timestampMs": 1341453375951,
         "latitude": 37.805624,
         "longitude": -122.422399
      },
      {
         "timestampMs": 1341452533763,
         "latitude": 37.8029465,
         "longitude": -122.4232979
      },
      {
         "timestampMs": 1341452470384,
         "latitude": 37.8053719,
         "longitude": -122.4220828
      },
      {
         "timestampMs": 1341451714000,
         "latitude": 37.805739,
         "longitude": -122.422281
      },
      {
         "timestampMs": 1341451153369,
         "latitude": 37.8058755,
         "longitude": -122.4220677
      },
      {
         "timestampMs": 1341450574924,
         "latitude": 37.8047178,
         "longitude": -122.4239408
      },
      {
         "timestampMs": 1341450508031,
         "latitude": 37.8052347,
         "longitude": -122.4247732
      },
      {
         "timestampMs": 1341450301224,
         "latitude": 37.8072386,
         "longitude": -122.4200345
      },
      {
         "timestampMs": 1341450191433,
         "latitude": 37.807752,
         "longitude": -122.4264579
      },
      {
         "timestampMs": 1341450171665,
         "latitude": 37.8071945,
         "longitude": -122.4199489
      },
      {
         "timestampMs": 1341450108654,
         "latitude": 37.8077693,
         "longitude": -122.4263995
      },
      {
         "timestampMs": 1341449823245,
         "latitude": 37.8068279,
         "longitude": -122.4196397
      },
      {
         "timestampMs": 1341449643214,
         "latitude": 37.8068067,
         "longitude": -122.4212673
      },
      {
         "timestampMs": 1341449223101,
         "latitude": 37.8071606,
         "longitude": -122.4200545
      },
      {
         "timestampMs": 1341449103070,
         "latitude": 37.8070489,
         "longitude": -122.4206677
      },
      {
         "timestampMs": 1341448862976,
         "latitude": 37.8068009,
         "longitude": -122.4212557
      },
      {
         "timestampMs": 1341448565332,
         "latitude": 37.8068279,
         "longitude": -122.4196397
      },
      {
         "timestampMs": 1341448291636,
         "latitude": 37.8079321,
         "longitude": -122.426451
      },
      {
         "timestampMs": 1341448096620,
         "latitude": 37.7994767,
         "longitude": -122.3988572
      },
      {
         "timestampMs": 1341447916621,
         "latitude": 37.8066235,
         "longitude": -122.4232409
      },
      {
         "timestampMs": 1341447734149,
         "latitude": 37.8068409,
         "longitude": -122.4212073
      },
      {
         "timestampMs": 1341447676488,
         "latitude": 37.8074335,
         "longitude": -122.4203487
      },
      {
         "timestampMs": 1341447437167,
         "latitude": 37.8080051,
         "longitude": -122.418104
      },
      {
         "timestampMs": 1341447258634,
         "latitude": 37.8076427,
         "longitude": -122.4166689
      },
      {
         "timestampMs": 1341447134029,
         "latitude": 37.8085242,
         "longitude": -122.4154932
      },
      {
         "timestampMs": 1341447013984,
         "latitude": 37.8087791,
         "longitude": -122.4138581
      },
      {
         "timestampMs": 1341446897383,
         "latitude": 37.8093025,
         "longitude": -122.4118694
      },
      {
         "timestampMs": 1341446893942,
         "latitude": 37.808941,
         "longitude": -122.4150621
      },
      {
         "timestampMs": 1341446833956,
         "latitude": 37.8092385,
         "longitude": -122.4117911
      },
      {
         "timestampMs": 1341446773930,
         "latitude": 37.8100583,
         "longitude": -122.4169839
      },
      {
         "timestampMs": 1341446594406,
         "latitude": 37.8095033,
         "longitude": -122.4160689
      },
      {
         "timestampMs": 1341446473763,
         "latitude": 37.8086086,
         "longitude": -122.4144502
      },
      {
         "timestampMs": 1341446413736,
         "latitude": 37.8087802,
         "longitude": -122.4151742
      },
      {
         "timestampMs": 1341446173714,
         "latitude": 37.8084876,
         "longitude": -122.415252
      },
      {
         "timestampMs": 1341445882449,
         "latitude": 37.8085885,
         "longitude": -122.4142583
      },
      {
         "timestampMs": 1341445694911,
         "latitude": 37.8085576,
         "longitude": -122.4127097
      },
      {
         "timestampMs": 1341445513601,
         "latitude": 37.8094358,
         "longitude": -122.4115789
      },
      {
         "timestampMs": 1341445453584,
         "latitude": 37.8083843,
         "longitude": -122.4120143
      },
      {
         "timestampMs": 1341445213589,
         "latitude": 37.8082215,
         "longitude": -122.4100017
      },
      {
         "timestampMs": 1341444973508,
         "latitude": 37.8085163,
         "longitude": -122.4113323
      },
      {
         "timestampMs": 1341444853387,
         "latitude": 37.808177,
         "longitude": -122.4100059
      },
      {
         "timestampMs": 1341444613311,
         "latitude": 37.8087688,
         "longitude": -122.4111446
      },
      {
         "timestampMs": 1341443879385,
         "latitude": 37.8075418,
         "longitude": -122.4122792
      },
      {
         "timestampMs": 1341443878007,
         "latitude": 37.8072562,
         "longitude": -122.4115545
      },
      {
         "timestampMs": 1341442544827,
         "latitude": 37.8075297,
         "longitude": -122.4121205
      },
      {
         "timestampMs": 1341442397774,
         "latitude": 37.8083419,
         "longitude": -122.4122332
      },
      {
         "timestampMs": 1341442217743,
         "latitude": 37.8087894,
         "longitude": -122.411683
      },
      {
         "timestampMs": 1341442098352,
         "latitude": 37.8094356,
         "longitude": -122.4113426
      },
      {
         "timestampMs": 1341442040315,
         "latitude": 37.8089571,
         "longitude": -122.4133496
      },
      {
         "timestampMs": 1341441928524,
         "latitude": 37.810646,
         "longitude": -122.4127129
      },
      {
         "timestampMs": 1341441923093,
         "latitude": 37.808995,
         "longitude": -122.411422
      },
      {
         "timestampMs": 1341441921325,
         "latitude": 37.808995,
         "longitude": -122.411422
      },
      {
         "timestampMs": 1341440173300,
         "latitude": 37.8073599,
         "longitude": -122.4691406
      },
      {
         "timestampMs": 1341439753224,
         "latitude": 37.8574562,
         "longitude": -122.484811
      },
      {
         "timestampMs": 1341439033099,
         "latitude": 37.801805,
         "longitude": -122.4477503
      },
      {
         "timestampMs": 1341438793021,
         "latitude": 37.8579833,
         "longitude": -122.4852967
      },
      {
         "timestampMs": 1341436332119,
         "latitude": 37.801805,
         "longitude": -122.4477503
      },
      {
         "timestampMs": 1341435911990,
         "latitude": 37.8579833,
         "longitude": -122.4852967
      },
      {
         "timestampMs": 1341435491926,
         "latitude": 37.801805,
         "longitude": -122.4477503
      },
      {
         "timestampMs": 1341435071791,
         "latitude": 37.8579833,
         "longitude": -122.4852967
      },
      {
         "timestampMs": 1341431405886,
         "latitude": 37.8586445,
         "longitude": -122.4832874
      },
      {
         "timestampMs": 1341431161505,
         "latitude": 37.7805782,
         "longitude": -122.412722
      },
      {
         "timestampMs": 1341430886131,
         "latitude": 37.8584352,
         "longitude": -122.4832658
      },
      {
         "timestampMs": 1341426510528,
         "latitude": 37.8713497,
         "longitude": -122.5081743
      },
      {
         "timestampMs": 1341421791476,
         "latitude": 37.7814058,
         "longitude": -122.41244
      },
      {
         "timestampMs": 1341419641989,
         "latitude": 37.8046649,
         "longitude": -122.4493867
      },
      {
         "timestampMs": 1341419401831,
         "latitude": 37.7992957,
         "longitude": -122.4389115
      },
      {
         "timestampMs": 1341418560844,
         "latitude": 37.8083488,
         "longitude": -122.412213
      },
      {
         "timestampMs": 1341418502008,
         "latitude": 37.8082959,
         "longitude": -122.4122044
      },
      {
         "timestampMs": 1341416313331,
         "latitude": 37.7869968,
         "longitude": -122.4264178
      },
      {
         "timestampMs": 1341414934613,
         "latitude": 37.7807066,
         "longitude": -122.4122665
      },
      {
         "timestampMs": 1341414694499,
         "latitude": 37.7813856,
         "longitude": -122.4116568
      },
      {
         "timestampMs": 1341414514382,
         "latitude": 37.7808015,
         "longitude": -122.4121355
      },
      {
         "timestampMs": 1341414453826,
         "latitude": 37.7808015,
         "longitude": -122.4121355
      },
      {
         "timestampMs": 1341414446986,
         "latitude": 37.7808015,
         "longitude": -122.4121355
      },
      {
         "timestampMs": 1341413140575,
         "latitude": 37.781598,
         "longitude": -122.4129814
      },
      {
         "timestampMs": 1341413138936,
         "latitude": 37.7823243,
         "longitude": -122.4133898
      },
      {
         "timestampMs": 1341411685837,
         "latitude": 37.7814791,
         "longitude": -122.4124485
      },
      {
         "timestampMs": 1341410605551,
         "latitude": 37.781434,
         "longitude": -122.4123791
      },
      {
         "timestampMs": 1341407004236,
         "latitude": 37.781434,
         "longitude": -122.4123791
      },
      {
         "timestampMs": 1341405262887,
         "latitude": 37.7814873,
         "longitude": -122.4124086
      },
      {
         "timestampMs": 1341405143743,
         "latitude": 37.7814873,
         "longitude": -122.4124086
      },
      {
         "timestampMs": 1341401542645,
         "latitude": 37.7814873,
         "longitude": -122.4124086
      },
      {
         "timestampMs": 1341397701370,
         "latitude": 37.7814016,
         "longitude": -122.4124118
      },
      {
         "timestampMs": 1341395121674,
         "latitude": 37.7816557,
         "longitude": -122.4127417
      },
      {
         "timestampMs": 1341395118933,
         "latitude": 37.7823243,
         "longitude": -122.4133898
      },
      {
         "timestampMs": 1341394100566,
         "latitude": 37.7814016,
         "longitude": -122.4124118
      },
      {
         "timestampMs": 1341393800526,
         "latitude": 37.7814251,
         "longitude": -122.4123778
      },
      {
         "timestampMs": 1341390198785,
         "latitude": 37.7814251,
         "longitude": -122.4123778
      },
      {
         "timestampMs": 1341389418599,
         "latitude": 37.7814519,
         "longitude": -122.4123273
      },
      {
         "timestampMs": 1341389358095,
         "latitude": 37.7814519,
         "longitude": -122.4123273
      },
      {
         "timestampMs": 1341385703593,
         "latitude": 37.7814519,
         "longitude": -122.4123273
      },
      {
         "timestampMs": 1341384084576,
         "latitude": 37.7812824,
         "longitude": -122.4124531
      },
      {
         "timestampMs": 1341381501627,
         "latitude": 37.7807099,
         "longitude": -122.4121719
      },
      {
         "timestampMs": 1341381381604,
         "latitude": 37.7807313,
         "longitude": -122.412143
      },
      {
         "timestampMs": 1341380540893,
         "latitude": 37.7815044,
         "longitude": -122.4123577
      },
      {
         "timestampMs": 1341377840145,
         "latitude": 37.7807599,
         "longitude": -122.4121179
      },
      {
         "timestampMs": 1341377102628,
         "latitude": 37.7809361,
         "longitude": -122.4120371
      },
      {
         "timestampMs": 1341373178000,
         "latitude": 37.808634,
         "longitude": -122.409813
      },
      {
         "timestampMs": 1341372830576,
         "latitude": 37.80842,
         "longitude": -122.4098774
      },
      {
         "timestampMs": 1341370309274,
         "latitude": 37.8055848,
         "longitude": -122.4205356
      },
      {
         "timestampMs": 1341369654643,
         "latitude": 37.8019823,
         "longitude": -122.4194783
      },
      {
         "timestampMs": 1341369081630,
         "latitude": 37.799449,
         "longitude": -122.4387047
      },
      {
         "timestampMs": 1341368054318,
         "latitude": 37.8005214,
         "longitude": -122.431284
      },
      {
         "timestampMs": 1341368037304,
         "latitude": 37.8005219,
         "longitude": -122.4314355
      },
      {
         "timestampMs": 1341368001627,
         "latitude": 37.8001616,
         "longitude": -122.4338249
      },
      {
         "timestampMs": 1341367944949,
         "latitude": 37.7997755,
         "longitude": -122.436593
      },
      {
         "timestampMs": 1341367882201,
         "latitude": 37.7989282,
         "longitude": -122.4427667
      },
      {
         "timestampMs": 1341367765141,
         "latitude": 37.7992603,
         "longitude": -122.4451568
      },
      {
         "timestampMs": 1341367703880,
         "latitude": 37.8003387,
         "longitude": -122.4473719
      },
      {
         "timestampMs": 1341367655512,
         "latitude": 37.800286,
         "longitude": -122.444003
      },
      {
         "timestampMs": 1341367462922,
         "latitude": 37.8067516,
         "longitude": -122.4748013
      },
      {
         "timestampMs": 1341367215234,
         "latitude": 37.8078405,
         "longitude": -122.4745289
      },
      {
         "timestampMs": 1341367167174,
         "latitude": 37.8064087,
         "longitude": -122.4727338
      },
      {
         "timestampMs": 1341366499570,
         "latitude": 37.7813827,
         "longitude": -122.412435
      },
      {
         "timestampMs": 1341364203784,
         "latitude": 37.7982641,
         "longitude": -122.4395578
      },
      {
         "timestampMs": 1341360333228,
         "latitude": 37.8039595,
         "longitude": -122.4486498
      },
      {
         "timestampMs": 1341360253323,
         "latitude": 37.8040489,
         "longitude": -122.4486312
      },
      {
         "timestampMs": 1341360086531,
         "latitude": 37.8044398,
         "longitude": -122.4486691
      },
      {
         "timestampMs": 1341359368468,
         "latitude": 37.8044398,
         "longitude": -122.4486691
      },
      {
         "timestampMs": 1341359128421,
         "latitude": 37.8035871,
         "longitude": -122.4488895
      },
      {
         "timestampMs": 1341359043661,
         "latitude": 37.7816196,
         "longitude": -122.4127027
      },
      {
         "timestampMs": 1341357867612,
         "latitude": 37.8029256,
         "longitude": -122.4496349
      },
      {
         "timestampMs": 1341357567532,
         "latitude": 37.802979,
         "longitude": -122.4496483
      },
      {
         "timestampMs": 1341357087530,
         "latitude": 37.8044398,
         "longitude": -122.4486691
      },
      {
         "timestampMs": 1341356682770,
         "latitude": 37.8033193,
         "longitude": -122.4495338
      },
      {
         "timestampMs": 1341353126082,
         "latitude": 37.8036052,
         "longitude": -122.4488533
      },
      {
         "timestampMs": 1341352826028,
         "latitude": 37.8034916,
         "longitude": -122.4488147
      },
      {
         "timestampMs": 1341352225847,
         "latitude": 37.8044398,
         "longitude": -122.4486691
      },
      {
         "timestampMs": 1341352165807,
         "latitude": 37.8035699,
         "longitude": -122.4488352
      },
      {
         "timestampMs": 1341351325650,
         "latitude": 37.8029718,
         "longitude": -122.449583
      },
      {
         "timestampMs": 1341351205606,
         "latitude": 37.8033346,
         "longitude": -122.4489584
      },
      {
         "timestampMs": 1341351145532,
         "latitude": 37.8030092,
         "longitude": -122.4496015
      },
      {
         "timestampMs": 1341351025580,
         "latitude": 37.8029272,
         "longitude": -122.4495841
      },
      {
         "timestampMs": 1341350365398,
         "latitude": 37.8029548,
         "longitude": -122.4495832
      },
      {
         "timestampMs": 1341350185490,
         "latitude": 37.8031582,
         "longitude": -122.4488561
      },
      {
         "timestampMs": 1341347964383,
         "latitude": 37.8026545,
         "longitude": -122.4496234
      },
      {
         "timestampMs": 1341346051625,
         "latitude": 37.802565,
         "longitude": -122.4496704
      },
      {
         "timestampMs": 1341342163002,
         "latitude": 37.802565,
         "longitude": -122.4496704
      },
      {
         "timestampMs": 1341341051000,
         "latitude": 37.80292,
         "longitude": -122.448348
      },
      {
         "timestampMs": 1341340842782,
         "latitude": 37.802565,
         "longitude": -122.4496704
      },
      {
         "timestampMs": 1341340664023,
         "latitude": 37.8028752,
         "longitude": -122.4495989
      },
      {
         "timestampMs": 1341335638761,
         "latitude": 37.80291,
         "longitude": -122.425192
      },
      {
         "timestampMs": 1341335082251,
         "latitude": 37.805298,
         "longitude": -122.424114
      },
      {
         "timestampMs": 1341334842168,
         "latitude": 37.8056192,
         "longitude": -122.4200743
      },
      {
         "timestampMs": 1341334368928,
         "latitude": 37.7976821,
         "longitude": -122.4092388
      },
      {
         "timestampMs": 1341333288509,
         "latitude": 37.7855728,
         "longitude": -122.4062766
      },
      {
         "timestampMs": 1341333227773,
         "latitude": 37.7841037,
         "longitude": -122.4083793
      },
      {
         "timestampMs": 1341333049444,
         "latitude": 37.7819554,
         "longitude": -122.4107539
      },
      {
         "timestampMs": 1341332928605,
         "latitude": 37.779625,
         "longitude": -122.413417
      },
      {
         "timestampMs": 1341332689015,
         "latitude": 37.7807176,
         "longitude": -122.4121693
      },
      {
         "timestampMs": 1341332627598,
         "latitude": 37.779625,
         "longitude": -122.413417
      },
      {
         "timestampMs": 1341332581199,
         "latitude": 37.7807938,
         "longitude": -122.4121454
      },
      {
         "timestampMs": 1341331260923,
         "latitude": 37.7814386,
         "longitude": -122.4124392
      },
      {
         "timestampMs": 1341329399949,
         "latitude": 37.7813983,
         "longitude": -122.4123812
      },
      {
         "timestampMs": 1341325799032,
         "latitude": 37.7813983,
         "longitude": -122.4123812
      },
      {
         "timestampMs": 1341323758475,
         "latitude": 37.7813983,
         "longitude": -122.4123812
      },
      {
         "timestampMs": 1341323338233,
         "latitude": 37.7813983,
         "longitude": -122.4123812
      },
      {
         "timestampMs": 1341319736914,
         "latitude": 37.7813983,
         "longitude": -122.4123812
      },
      {
         "timestampMs": 1341319676906,
         "latitude": 37.7813983,
         "longitude": -122.4123812
      },
      {
         "timestampMs": 1341319556869,
         "latitude": 37.7813983,
         "longitude": -122.4123812
      },
      {
         "timestampMs": 1341315955886,
         "latitude": 37.7813983,
         "longitude": -122.4123812
      },
      {
         "timestampMs": 1341314515541,
         "latitude": 37.7814439,
         "longitude": -122.4124009
      },
      {
         "timestampMs": 1341313915276,
         "latitude": 37.7814439,
         "longitude": -122.4124009
      },
      {
         "timestampMs": 1341310304561,
         "latitude": 37.7814439,
         "longitude": -122.4124009
      },
      {
         "timestampMs": 1341309884329,
         "latitude": 37.7814439,
         "longitude": -122.4124009
      },
      {
         "timestampMs": 1341309824304,
         "latitude": 37.7814439,
         "longitude": -122.4124009
      },
      {
         "timestampMs": 1341306223019,
         "latitude": 37.7814439,
         "longitude": -122.4124009
      },
      {
         "timestampMs": 1341305802854,
         "latitude": 37.7814439,
         "longitude": -122.4124009
      },
      {
         "timestampMs": 1341305742871,
         "latitude": 37.7814439,
         "longitude": -122.4124009
      },
      {
         "timestampMs": 1341305622795,
         "latitude": 37.7814439,
         "longitude": -122.4124009
      },
      {
         "timestampMs": 1341302021770,
         "latitude": 37.7814439,
         "longitude": -122.4124009
      },
      {
         "timestampMs": 1341300881555,
         "latitude": 37.7814583,
         "longitude": -122.4124181
      },
      {
         "timestampMs": 1341297280441,
         "latitude": 37.7814583,
         "longitude": -122.4124181
      },
      {
         "timestampMs": 1341296470915,
         "latitude": 37.7807595,
         "longitude": -122.4121392
      },
      {
         "timestampMs": 1341296455176,
         "latitude": 37.781058,
         "longitude": -122.411855
      },
      {
         "timestampMs": 1341293497962,
         "latitude": 37.7808125,
         "longitude": -122.4120988
      },
      {
         "timestampMs": 1341292797222,
         "latitude": 37.7807182,
         "longitude": -122.4121603
      },
      {
         "timestampMs": 1341289774670,
         "latitude": 37.7804097,
         "longitude": -122.4126586
      },
      {
         "timestampMs": 1341289533635,
         "latitude": 37.7814398,
         "longitude": -122.4124515
      },
      {
         "timestampMs": 1341289526713,
         "latitude": 37.781477,
         "longitude": -122.4123735
      },
      {
         "timestampMs": 1341285197980,
         "latitude": 37.7814398,
         "longitude": -122.4124515
      },
      {
         "timestampMs": 1341283225005,
         "latitude": 37.7806823,
         "longitude": -122.4121324
      },
      {
         "timestampMs": 1341283218539,
         "latitude": 37.7807703,
         "longitude": -122.4121364
      },
      {
         "timestampMs": 1341283155156,
         "latitude": 37.7803458,
         "longitude": -122.4126934
      },
      {
         "timestampMs": 1341283103437,
         "latitude": 37.7804182,
         "longitude": -122.4126331
      },
      {
         "timestampMs": 1341281691395,
         "latitude": 37.7761195,
         "longitude": -122.3945155
      },
      {
         "timestampMs": 1341281689404,
         "latitude": 37.77554,
         "longitude": -122.394663
      },
      {
         "timestampMs": 1341281632414,
         "latitude": 37.7765068,
         "longitude": -122.3950553
      },
      {
         "timestampMs": 1341281093406,
         "latitude": 37.7763052,
         "longitude": -122.3943435
      },
      {
         "timestampMs": 1341281033329,
         "latitude": 37.7761632,
         "longitude": -122.3935576
      },
      {
         "timestampMs": 1341278872225,
         "latitude": 37.4858405,
         "longitude": -122.2314634
      },
      {
         "timestampMs": 1341278034175,
         "latitude": 37.5629136,
         "longitude": -122.3184815
      },
      {
         "timestampMs": 1341277912228,
         "latitude": 37.5414273,
         "longitude": -122.2987619
      },
      {
         "timestampMs": 1341277736986,
         "latitude": 37.5367831,
         "longitude": -122.297002
      },
      {
         "timestampMs": 1341277673300,
         "latitude": 37.5241364,
         "longitude": -122.2803866
      },
      {
         "timestampMs": 1341277613359,
         "latitude": 37.5106975,
         "longitude": -122.2639046
      },
      {
         "timestampMs": 1341277492139,
         "latitude": 37.5069783,
         "longitude": -122.2602814
      },
      {
         "timestampMs": 1341277433303,
         "latitude": 37.5022943,
         "longitude": -122.2546108
      },
      {
         "timestampMs": 1341277314353,
         "latitude": 37.4801251,
         "longitude": -122.2234836
      },
      {
         "timestampMs": 1341277251343,
         "latitude": 37.4603619,
         "longitude": -122.1941142
      },
      {
         "timestampMs": 1341277070891,
         "latitude": 37.4549487,
         "longitude": -122.1791845
      },
      {
         "timestampMs": 1341276650849,
         "latitude": 37.4434786,
         "longitude": -122.1648567
      },
      {
         "timestampMs": 1341276605000,
         "latitude": 37.44307,
         "longitude": -122.1649
      },
      {
         "timestampMs": 1341276412436,
         "latitude": 37.4436889,
         "longitude": -122.1676867
      },
      {
         "timestampMs": 1341271744276,
         "latitude": 37.427903,
         "longitude": -122.1688026
      },
      {
         "timestampMs": 1341271564237,
         "latitude": 37.4276787,
         "longitude": -122.1690827
      },
      {
         "timestampMs": 1341271394000,
         "latitude": 37.428301,
         "longitude": -122.16883
      },
      {
         "timestampMs": 1341271203309,
         "latitude": 37.4277457,
         "longitude": -122.1685183
      },
      {
         "timestampMs": 1341271144218,
         "latitude": 37.4280728,
         "longitude": -122.1683509
      },
      {
         "timestampMs": 1341271141784,
         "latitude": 37.4277146,
         "longitude": -122.1685304
      },
      {
         "timestampMs": 1341270196086,
         "latitude": 37.4355352,
         "longitude": -122.167674
      },
      {
         "timestampMs": 1341270136058,
         "latitude": 37.4371111,
         "longitude": -122.1651621
      },
      {
         "timestampMs": 1341270131154,
         "latitude": 37.4365415,
         "longitude": -122.1644137
      },
      {
         "timestampMs": 1341270070947,
         "latitude": 37.4371668,
         "longitude": -122.1599938
      },
      {
         "timestampMs": 1341269548120,
         "latitude": 37.3778585,
         "longitude": -122.1492118
      },
      {
         "timestampMs": 1341269426719,
         "latitude": 37.3567039,
         "longitude": -122.1156134
      },
      {
         "timestampMs": 1341269274000,
         "latitude": 37.332222,
         "longitude": -122.030747
      },
      {
         "timestampMs": 1341269187594,
         "latitude": 37.3339153,
         "longitude": -122.0601965
      },
      {
         "timestampMs": 1341269078097,
         "latitude": 37.3328909,
         "longitude": -122.0310038
      },
      {
         "timestampMs": 1341269016550,
         "latitude": 37.330837,
         "longitude": -122.0311383
      },
      {
         "timestampMs": 1341268888052,
         "latitude": 37.3332606,
         "longitude": -122.0307211
      },
      {
         "timestampMs": 1341268519117,
         "latitude": 37.3297862,
         "longitude": -122.0325639
      },
      {
         "timestampMs": 1341268513007,
         "latitude": 37.3293314,
         "longitude": -122.0324226
      },
      {
         "timestampMs": 1341268452449,
         "latitude": 37.3262132,
         "longitude": -122.0323721
      },
      {
         "timestampMs": 1341268418837,
         "latitude": 37.3227502,
         "longitude": -122.0321737
      },
      {
         "timestampMs": 1341268413832,
         "latitude": 37.3230001,
         "longitude": -122.0315908
      },
      {
         "timestampMs": 1341268409525,
         "latitude": 37.322747,
         "longitude": -122.0320558
      },
      {
         "timestampMs": 1341262617963,
         "latitude": 37.3568848,
         "longitude": -122.0626329
      },
      {
         "timestampMs": 1341262593983,
         "latitude": 37.3684748,
         "longitude": -122.0605677
      },
      {
         "timestampMs": 1341262267125,
         "latitude": 37.4203457,
         "longitude": -122.0784231
      },
      {
         "timestampMs": 1341262208643,
         "latitude": 37.4206152,
         "longitude": -122.0822926
      },
      {
         "timestampMs": 1341261786721,
         "latitude": 37.4214944,
         "longitude": -122.0842496
      },
      {
         "timestampMs": 1341261366137,
         "latitude": 37.4201693,
         "longitude": -122.0852086
      },
      {
         "timestampMs": 1341261246931,
         "latitude": 37.4214753,
         "longitude": -122.085277
      },
      {
         "timestampMs": 1341261048505,
         "latitude": 37.42226,
         "longitude": -122.0853867
      },
      {
         "timestampMs": 1341260807501,
         "latitude": 37.4221692,
         "longitude": -122.0854432
      },
      {
         "timestampMs": 1341260687417,
         "latitude": 37.4213363,
         "longitude": -122.0852973
      },
      {
         "timestampMs": 1341260567003,
         "latitude": 37.4214555,
         "longitude": -122.0837962
      },
      {
         "timestampMs": 1341259792457,
         "latitude": 37.4219748,
         "longitude": -122.0855412
      },
      {
         "timestampMs": 1341259373242,
         "latitude": 37.4219628,
         "longitude": -122.0847814
      },
      {
         "timestampMs": 1341258713488,
         "latitude": 37.4215611,
         "longitude": -122.0841252
      },
      {
         "timestampMs": 1341258592708,
         "latitude": 37.4219218,
         "longitude": -122.0846161
      },
      {
         "timestampMs": 1341257691875,
         "latitude": 37.4220011,
         "longitude": -122.0857847
      },
      {
         "timestampMs": 1341257032269,
         "latitude": 37.4232182,
         "longitude": -122.0868394
      },
      {
         "timestampMs": 1341256852245,
         "latitude": 37.4232182,
         "longitude": -122.0868394
      },
      {
         "timestampMs": 1341256732374,
         "latitude": 37.4217062,
         "longitude": -122.0879443
      },
      {
         "timestampMs": 1341256492537,
         "latitude": 37.4229664,
         "longitude": -122.0875008
      },
      {
         "timestampMs": 1341256432169,
         "latitude": 37.4223938,
         "longitude": -122.0875588
      },
      {
         "timestampMs": 1341256372163,
         "latitude": 37.4232182,
         "longitude": -122.0868394
      },
      {
         "timestampMs": 1341256146275,
         "latitude": 37.4224235,
         "longitude": -122.0876138
      },
      {
         "timestampMs": 1341256086230,
         "latitude": 37.4229247,
         "longitude": -122.087424
      },
      {
         "timestampMs": 1341255966613,
         "latitude": 37.4224328,
         "longitude": -122.0875827
      },
      {
         "timestampMs": 1341255846131,
         "latitude": 37.42288,
         "longitude": -122.087424
      },
      {
         "timestampMs": 1341255726331,
         "latitude": 37.4224322,
         "longitude": -122.0875543
      },
      {
         "timestampMs": 1341255185964,
         "latitude": 37.4232182,
         "longitude": -122.0868394
      },
      {
         "timestampMs": 1341255126050,
         "latitude": 37.4229664,
         "longitude": -122.0875008
      },
      {
         "timestampMs": 1341254525797,
         "latitude": 37.422544,
         "longitude": -122.0877568
      },
      {
         "timestampMs": 1341254278000,
         "latitude": 37.42256,
         "longitude": -122.087654
      },
      {
         "timestampMs": 1341254275312,
         "latitude": 37.4217062,
         "longitude": -122.0879443
      },
      {
         "timestampMs": 1341254094743,
         "latitude": 37.4224423,
         "longitude": -122.0875738
      },
      {
         "timestampMs": 1341252447000,
         "latitude": 37.454604,
         "longitude": -122.182518
      },
      {
         "timestampMs": 1341252187053,
         "latitude": 37.4451361,
         "longitude": -122.1655787
      },
      {
         "timestampMs": 1341252008458,
         "latitude": 37.4549487,
         "longitude": -122.1791845
      },
      {
         "timestampMs": 1341251131549,
         "latitude": 37.5367326,
         "longitude": -122.2966789
      },
      {
         "timestampMs": 1341250999592,
         "latitude": 37.5501487,
         "longitude": -122.3077448
      },
      {
         "timestampMs": 1341250880802,
         "latitude": 37.5569574,
         "longitude": -122.3121117
      },
      {
         "timestampMs": 1341250820329,
         "latitude": 37.5643271,
         "longitude": -122.3198935
      },
      {
         "timestampMs": 1341249113991,
         "latitude": 37.7583423,
         "longitude": -122.3929402
      },
      {
         "timestampMs": 1341248994817,
         "latitude": 37.767003,
         "longitude": -122.3964487
      },
      {
         "timestampMs": 1341248626000,
         "latitude": 37.776617,
         "longitude": -122.394687
      },
      {
         "timestampMs": 1341248033091,
         "latitude": 37.776535,
         "longitude": -122.394521
      },
      {
         "timestampMs": 1341245557885,
         "latitude": 37.7825743,
         "longitude": -122.388236
      },
      {
         "timestampMs": 1341244355120,
         "latitude": 37.7803471,
         "longitude": -122.4126935
      },
      {
         "timestampMs": 1341244115324,
         "latitude": 37.7807138,
         "longitude": -122.4121859
      },
      {
         "timestampMs": 1341244053994,
         "latitude": 37.7807506,
         "longitude": -122.4121034
      },
      {
         "timestampMs": 1341244027357,
         "latitude": 37.7807401,
         "longitude": -122.412166
      },
      {
         "timestampMs": 1341243933865,
         "latitude": 37.7804936,
         "longitude": -122.4126452
      },
      {
         "timestampMs": 1341243214522,
         "latitude": 37.7812928,
         "longitude": -122.4126974
      },
      {
         "timestampMs": 1341243153497,
         "latitude": 37.7812928,
         "longitude": -122.4126974
      },
      {
         "timestampMs": 1341241717622,
         "latitude": 37.7814927,
         "longitude": -122.4123745
      },
      {
         "timestampMs": 1341239250974,
         "latitude": 37.7812928,
         "longitude": -122.4126974
      },
      {
         "timestampMs": 1341237936370,
         "latitude": 37.7815014,
         "longitude": -122.4123544
      },
      {
         "timestampMs": 1341237875436,
         "latitude": 37.7815014,
         "longitude": -122.4123544
      },
      {
         "timestampMs": 1341237091713,
         "latitude": 37.7812928,
         "longitude": -122.4126974
      },
      {
         "timestampMs": 1341234274243,
         "latitude": 37.7815014,
         "longitude": -122.4123544
      },
      {
         "timestampMs": 1341233472964,
         "latitude": 37.7812928,
         "longitude": -122.4126974
      },
      {
         "timestampMs": 1341232834857,
         "latitude": 37.7815014,
         "longitude": -122.4123544
      },
      {
         "timestampMs": 1341232773917,
         "latitude": 37.7815014,
         "longitude": -122.4123544
      },
      {
         "timestampMs": 1341232654801,
         "latitude": 37.7815014,
         "longitude": -122.4123544
      },
      {
         "timestampMs": 1341232473868,
         "latitude": 37.7815014,
         "longitude": -122.4123544
      },
      {
         "timestampMs": 1341232392091,
         "latitude": 37.7812928,
         "longitude": -122.4126974
      },
      {
         "timestampMs": 1341231430188,
         "latitude": 37.7812928,
         "longitude": -122.4126974
      },
      {
         "timestampMs": 1341228873259,
         "latitude": 37.7815014,
         "longitude": -122.4123544
      },
      {
         "timestampMs": 1341228513711,
         "latitude": 37.7814448,
         "longitude": -122.4123885
      },
      {
         "timestampMs": 1341228393715,
         "latitude": 37.7814448,
         "longitude": -122.4123885
      },
      {
         "timestampMs": 1341228273221,
         "latitude": 37.7814448,
         "longitude": -122.4123885
      },
      {
         "timestampMs": 1341227541451,
         "latitude": 37.7812928,
         "longitude": -122.4126974
      },
      {
         "timestampMs": 1341225989648,
         "latitude": 37.7814366,
         "longitude": -122.4124518
      },
      {
         "timestampMs": 1341224640112,
         "latitude": 37.7814448,
         "longitude": -122.4123885
      },
      {
         "timestampMs": 1341223379879,
         "latitude": 37.7814474,
         "longitude": -122.4124063
      },
      {
         "timestampMs": 1341223319814,
         "latitude": 37.7814474,
         "longitude": -122.4124063
      },
      {
         "timestampMs": 1341220770554,
         "latitude": 37.7814366,
         "longitude": -122.4124518
      },
      {
         "timestampMs": 1341219717680,
         "latitude": 37.7814474,
         "longitude": -122.4124063
      },
      {
         "timestampMs": 1341216096019,
         "latitude": 37.7814366,
         "longitude": -122.4124518
      },
      {
         "timestampMs": 1341209415746,
         "latitude": 37.780881,
         "longitude": -122.413344
      },
      {
         "timestampMs": 1341205968531,
         "latitude": 37.780769,
         "longitude": -122.4121407
      },
      {
         "timestampMs": 1341205848589,
         "latitude": 37.781058,
         "longitude": -122.411855
      },
      {
         "timestampMs": 1341204693370,
         "latitude": 37.7807383,
         "longitude": -122.4121568
      },
      {
         "timestampMs": 1341202241858,
         "latitude": 37.7807068,
         "longitude": -122.4121607
      },
      {
         "timestampMs": 1341202176741,
         "latitude": 37.7810832,
         "longitude": -122.4123271
      },
      {
         "timestampMs": 1341201812149,
         "latitude": 37.7814845,
         "longitude": -122.4124265
      },
      {
         "timestampMs": 1341200260853,
         "latitude": 37.7807884,
         "longitude": -122.4123111
      },
      {
         "timestampMs": 1341200131888,
         "latitude": 37.7804315,
         "longitude": -122.4126775
      },
      {
         "timestampMs": 1341199488779,
         "latitude": 37.7804834,
         "longitude": -122.4124206
      },
      {
         "timestampMs": 1341195672041,
         "latitude": 37.7813485,
         "longitude": -122.4118551
      },
      {
         "timestampMs": 1341195612070,
         "latitude": 37.7808825,
         "longitude": -122.4122864
      },
      {
         "timestampMs": 1341195552008,
         "latitude": 37.7803869,
         "longitude": -122.412569
      },
      {
         "timestampMs": 1341195432028,
         "latitude": 37.7792646,
         "longitude": -122.419618
      },
      {
         "timestampMs": 1341195371988,
         "latitude": 37.7800275,
         "longitude": -122.4203675
      },
      {
         "timestampMs": 1341193692022,
         "latitude": 37.7736588,
         "longitude": -122.4634514
      },
      {
         "timestampMs": 1341193163927,
         "latitude": 37.7702809,
         "longitude": -122.4670071
      },
      {
         "timestampMs": 1341189534924,
         "latitude": 37.7668497,
         "longitude": -122.4725422
      },
      {
         "timestampMs": 1341189385886,
         "latitude": 37.7668591,
         "longitude": -122.4725218
      },
      {
         "timestampMs": 1341189266938,
         "latitude": 37.763388,
         "longitude": -122.471275
      },
      {
         "timestampMs": 1341183534430,
         "latitude": 37.7699717,
         "longitude": -122.46653
      },
      {
         "timestampMs": 1341183295734,
         "latitude": 37.7698935,
         "longitude": -122.4666346
      },
      {
         "timestampMs": 1341183115683,
         "latitude": 37.7701708,
         "longitude": -122.4657455
      },
      {
         "timestampMs": 1341182994331,
         "latitude": 37.7698027,
         "longitude": -122.4661353
      },
      {
         "timestampMs": 1341182635496,
         "latitude": 37.7697959,
         "longitude": -122.4673635
      },
      {
         "timestampMs": 1341181939987,
         "latitude": 37.7696259,
         "longitude": -122.4667191
      },
      {
         "timestampMs": 1341181698827,
         "latitude": 37.769804,
         "longitude": -122.4673407
      },
      {
         "timestampMs": 1341180595022,
         "latitude": 37.7696296,
         "longitude": -122.4666499
      },
      {
         "timestampMs": 1341180353658,
         "latitude": 37.7697638,
         "longitude": -122.4661294
      },
      {
         "timestampMs": 1341179995033,
         "latitude": 37.7698401,
         "longitude": -122.4660926
      },
      {
         "timestampMs": 1341176752170,
         "latitude": 37.7696498,
         "longitude": -122.4666667
      },
      {
         "timestampMs": 1341176631954,
         "latitude": 37.7696627,
         "longitude": -122.4666245
      },
      {
         "timestampMs": 1341176573312,
         "latitude": 37.7696627,
         "longitude": -122.4666245
      },
      {
         "timestampMs": 1341176513244,
         "latitude": 37.7696627,
         "longitude": -122.4666245
      },
      {
         "timestampMs": 1341176453214,
         "latitude": 37.7696627,
         "longitude": -122.4666245
      },
      {
         "timestampMs": 1341172849750,
         "latitude": 37.7696627,
         "longitude": -122.4666245
      },
      {
         "timestampMs": 1341172626456,
         "latitude": 37.7805068,
         "longitude": -122.4124103
      },
      {
         "timestampMs": 1341172369868,
         "latitude": 37.7700356,
         "longitude": -122.4665414
      },
      {
         "timestampMs": 1341171649397,
         "latitude": 37.7696903,
         "longitude": -122.4663648
      },
      {
         "timestampMs": 1341170929100,
         "latitude": 37.7696921,
         "longitude": -122.4663519
      },
      {
         "timestampMs": 1341169600092,
         "latitude": 37.7695766,
         "longitude": -122.466609
      },
      {
         "timestampMs": 1341167498981,
         "latitude": 37.7699398,
         "longitude": -122.4663251
      },
      {
         "timestampMs": 1341166058876,
         "latitude": 37.7701605,
         "longitude": -122.4657791
      },
      {
         "timestampMs": 1341165518644,
         "latitude": 37.7697973,
         "longitude": -122.4661421
      },
      {
         "timestampMs": 1341165462641,
         "latitude": 37.7698096,
         "longitude": -122.4661772
      },
      {
         "timestampMs": 1341164228000,
         "latitude": 37.769979,
         "longitude": -122.466288
      },
      {
         "timestampMs": 1341163657422,
         "latitude": 37.7702503,
         "longitude": -122.4669575
      },
      {
         "timestampMs": 1341160831155,
         "latitude": 37.7804817,
         "longitude": -122.412425
      },
      {
         "timestampMs": 1341159870211,
         "latitude": 37.7801862,
         "longitude": -122.4203087
      },
      {
         "timestampMs": 1341159752732,
         "latitude": 37.7797715,
         "longitude": -122.4197933
      },
      {
         "timestampMs": 1341159690815,
         "latitude": 37.779674,
         "longitude": -122.4172167
      },
      {
         "timestampMs": 1341158790190,
         "latitude": 37.780398,
         "longitude": -122.4127205
      },
      {
         "timestampMs": 1341158430109,
         "latitude": 37.7811528,
         "longitude": -122.4138706
      },
      {
         "timestampMs": 1341158190452,
         "latitude": 37.7807656,
         "longitude": -122.4121488
      },
      {
         "timestampMs": 1341157937515,
         "latitude": 37.7807559,
         "longitude": -122.4121554
      },
      {
         "timestampMs": 1341157636726,
         "latitude": 37.7814782,
         "longitude": -122.4123193
      },
      {
         "timestampMs": 1341154844288,
         "latitude": 37.7814755,
         "longitude": -122.4123467
      },
      {
         "timestampMs": 1341154724271,
         "latitude": 37.7814755,
         "longitude": -122.4123467
      },
      {
         "timestampMs": 1341154545107,
         "latitude": 37.7814755,
         "longitude": -122.4123467
      },
      {
         "timestampMs": 1341150943912,
         "latitude": 37.7814755,
         "longitude": -122.4123467
      },
      {
         "timestampMs": 1341146801658,
         "latitude": 37.7814497,
         "longitude": -122.4123826
      },
      {
         "timestampMs": 1341146742522,
         "latitude": 37.7814497,
         "longitude": -122.4123826
      },
      {
         "timestampMs": 1341143141141,
         "latitude": 37.7814497,
         "longitude": -122.4123826
      },
      {
         "timestampMs": 1341142661014,
         "latitude": 37.7814497,
         "longitude": -122.4123826
      },
      {
         "timestampMs": 1341142120907,
         "latitude": 37.7814497,
         "longitude": -122.4123826
      },
      {
         "timestampMs": 1341138519169,
         "latitude": 37.7814497,
         "longitude": -122.4123826
      },
      {
         "timestampMs": 1341133117436,
         "latitude": 37.7814341,
         "longitude": -122.4123753
      },
      {
         "timestampMs": 1341132877194,
         "latitude": 37.7814341,
         "longitude": -122.4123753
      },
      {
         "timestampMs": 1341132757164,
         "latitude": 37.7814341,
         "longitude": -122.4123753
      },
      {
         "timestampMs": 1341132577158,
         "latitude": 37.7814341,
         "longitude": -122.4123753
      },
      {
         "timestampMs": 1341132517108,
         "latitude": 37.7814341,
         "longitude": -122.4123753
      },
      {
         "timestampMs": 1341128916146,
         "latitude": 37.7814341,
         "longitude": -122.4123753
      },
      {
         "timestampMs": 1341121975666,
         "latitude": 37.7807478,
         "longitude": -122.4121809
      },
      {
         "timestampMs": 1341121918674,
         "latitude": 37.7808046,
         "longitude": -122.4121389
      },
      {
         "timestampMs": 1341121886881,
         "latitude": 37.7853543,
         "longitude": -122.4094236
      },
      {
         "timestampMs": 1341121858686,
         "latitude": 37.7840714,
         "longitude": -122.4125954
      },
      {
         "timestampMs": 1341121795563,
         "latitude": 37.7858645,
         "longitude": -122.409383
      },
      {
         "timestampMs": 1341121736964,
         "latitude": 37.7860985,
         "longitude": -122.4097995
      },
      {
         "timestampMs": 1341121678662,
         "latitude": 37.7852187,
         "longitude": -122.4093788
      },
      {
         "timestampMs": 1341121555429,
         "latitude": 37.7873974,
         "longitude": -122.4087236
      },
      {
         "timestampMs": 1341121379341,
         "latitude": 37.7873586,
         "longitude": -122.4087621
      },
      {
         "timestampMs": 1341121195177,
         "latitude": 37.7880978,
         "longitude": -122.4098234
      },
      {
         "timestampMs": 1341121139436,
         "latitude": 37.7881107,
         "longitude": -122.4096904
      },
      {
         "timestampMs": 1341121019416,
         "latitude": 37.7882843,
         "longitude": -122.4102766
      },
      {
         "timestampMs": 1341120955594,
         "latitude": 37.7891658,
         "longitude": -122.409587
      },
      {
         "timestampMs": 1341120898952,
         "latitude": 37.7890814,
         "longitude": -122.4095299
      },
      {
         "timestampMs": 1341120838375,
         "latitude": 37.7893251,
         "longitude": -122.4079504
      },
      {
         "timestampMs": 1341120778325,
         "latitude": 37.7896038,
         "longitude": -122.4058163
      },
      {
         "timestampMs": 1341120719396,
         "latitude": 37.7897169,
         "longitude": -122.4048972
      },
      {
         "timestampMs": 1341120654617,
         "latitude": 37.7933748,
         "longitude": -122.4030115
      },
      {
         "timestampMs": 1341120637167,
         "latitude": 37.7896449,
         "longitude": -122.4039219
      },
      {
         "timestampMs": 1341120628220,
         "latitude": 37.7901012,
         "longitude": -122.4019851
      },
      {
         "timestampMs": 1341120534600,
         "latitude": 37.7942551,
         "longitude": -122.4031109
      },
      {
         "timestampMs": 1341120514911,
         "latitude": 37.7934651,
         "longitude": -122.4029805
      },
      {
         "timestampMs": 1341120454899,
         "latitude": 37.7947923,
         "longitude": -122.4033573
      },
      {
         "timestampMs": 1341120352937,
         "latitude": 37.7972078,
         "longitude": -122.4058762
      },
      {
         "timestampMs": 1341120333955,
         "latitude": 37.7961855,
         "longitude": -122.4045041
      },
      {
         "timestampMs": 1341120293060,
         "latitude": 37.7978296,
         "longitude": -122.4070486
      },
      {
         "timestampMs": 1341120273930,
         "latitude": 37.7972009,
         "longitude": -122.4058983
      },
      {
         "timestampMs": 1341120214835,
         "latitude": 37.797927,
         "longitude": -122.4070448
      },
      {
         "timestampMs": 1341120175328,
         "latitude": 37.7976516,
         "longitude": -122.4084797
      },
      {
         "timestampMs": 1341120154819,
         "latitude": 37.7977036,
         "longitude": -122.4086624
      },
      {
         "timestampMs": 1341120110955,
         "latitude": 37.7958492,
         "longitude": -122.4216918
      },
      {
         "timestampMs": 1341120035104,
         "latitude": 37.7959893,
         "longitude": -122.4216941
      },
      {
         "timestampMs": 1341120001195,
         "latitude": 37.8001416,
         "longitude": -122.4248652
      },
      {
         "timestampMs": 1341119976008,
         "latitude": 37.7990674,
         "longitude": -122.4242733
      },
      {
         "timestampMs": 1341119914761,
         "latitude": 37.8001829,
         "longitude": -122.4248806
      },
      {
         "timestampMs": 1341119872171,
         "latitude": 37.7997949,
         "longitude": -122.429393
      },
      {
         "timestampMs": 1341119752973,
         "latitude": 37.8010505,
         "longitude": -122.4257833
      },
      {
         "timestampMs": 1341119692081,
         "latitude": 37.8033985,
         "longitude": -122.4247521
      },
      {
         "timestampMs": 1341119615910,
         "latitude": 37.80291,
         "longitude": -122.425192
      },
      {
         "timestampMs": 1341119572048,
         "latitude": 37.8053244,
         "longitude": -122.4227554
      },
      {
         "timestampMs": 1341119554724,
         "latitude": 37.805298,
         "longitude": -122.424114
      },
      {
         "timestampMs": 1341119513682,
         "latitude": 37.8054203,
         "longitude": -122.4225008
      },
      {
         "timestampMs": 1341119374599,
         "latitude": 37.8056278,
         "longitude": -122.4200931
      },
      {
         "timestampMs": 1341119288877,
         "latitude": 37.8059751,
         "longitude": -122.4181605
      },
      {
         "timestampMs": 1341119278137,
         "latitude": 37.8062567,
         "longitude": -122.4174616
      },
      {
         "timestampMs": 1341119274123,
         "latitude": 37.8057181,
         "longitude": -122.4172792
      },
      {
         "timestampMs": 1341119264472,
         "latitude": 37.806185,
         "longitude": -122.4176166
      },
      {
         "timestampMs": 1341119216142,
         "latitude": 37.8073229,
         "longitude": -122.4135101
      },
      {
         "timestampMs": 1341119210065,
         "latitude": 37.8072216,
         "longitude": -122.4157714
      },
      {
         "timestampMs": 1341119102218,
         "latitude": 37.8070308,
         "longitude": -122.4145333
      },
      {
         "timestampMs": 1341119038300,
         "latitude": 37.8073387,
         "longitude": -122.4132421
      },
      {
         "timestampMs": 1341118977207,
         "latitude": 37.8036911,
         "longitude": -122.4019296
      },
      {
         "timestampMs": 1341118909940,
         "latitude": 37.8041764,
         "longitude": -122.4026042
      },
      {
         "timestampMs": 1341118860381,
         "latitude": 37.7978184,
         "longitude": -122.3967424
      },
      {
         "timestampMs": 1341118797356,
         "latitude": 37.7965855,
         "longitude": -122.3962591
      },
      {
         "timestampMs": 1341118790330,
         "latitude": 37.7991382,
         "longitude": -122.3981069
      },
      {
         "timestampMs": 1341118741311,
         "latitude": 37.7963211,
         "longitude": -122.3964736
      },
      {
         "timestampMs": 1341118729998,
         "latitude": 37.7966021,
         "longitude": -122.3959763
      },
      {
         "timestampMs": 1341118612651,
         "latitude": 37.7941014,
         "longitude": -122.3967951
      },
      {
         "timestampMs": 1341118557223,
         "latitude": 37.7939491,
         "longitude": -122.3966461
      },
      {
         "timestampMs": 1341118377335,
         "latitude": 37.7880565,
         "longitude": -122.3996146
      },
      {
         "timestampMs": 1341118369512,
         "latitude": 37.7908126,
         "longitude": -122.3956713
      },
      {
         "timestampMs": 1341118257818,
         "latitude": 37.7845845,
         "longitude": -122.3948139
      },
      {
         "timestampMs": 1341118189498,
         "latitude": 37.7845056,
         "longitude": -122.3948325
      },
      {
         "timestampMs": 1341118129496,
         "latitude": 37.786555,
         "longitude": -122.392464
      },
      {
         "timestampMs": 1341118077202,
         "latitude": 37.7861015,
         "longitude": -122.3909168
      },
      {
         "timestampMs": 1341118069345,
         "latitude": 37.7854128,
         "longitude": -122.3909878
      },
      {
         "timestampMs": 1341117967714,
         "latitude": 37.7873238,
         "longitude": -122.3906228
      },
      {
         "timestampMs": 1341117656979,
         "latitude": 37.8246282,
         "longitude": -122.3080906
      },
      {
         "timestampMs": 1341117603110,
         "latitude": 37.8128807,
         "longitude": -122.3535331
      },
      {
         "timestampMs": 1341117543096,
         "latitude": 37.824162,
         "longitude": -122.3159809
      },
      {
         "timestampMs": 1341117483401,
         "latitude": 37.8212557,
         "longitude": -122.2959053
      },
      {
         "timestampMs": 1341117363136,
         "latitude": 37.8027536,
         "longitude": -122.2806359
      },
      {
         "timestampMs": 1341117182428,
         "latitude": 37.7782231,
         "longitude": -122.2373654
      },
      {
         "timestampMs": 1341117062780,
         "latitude": 37.7700798,
         "longitude": -122.2232194
      },
      {
         "timestampMs": 1341117002730,
         "latitude": 37.7533601,
         "longitude": -122.2074306
      },
      {
         "timestampMs": 1341116882757,
         "latitude": 37.7305033,
         "longitude": -122.187164
      },
      {
         "timestampMs": 1341116876828,
         "latitude": 37.7119028,
         "longitude": -122.1679531
      },
      {
         "timestampMs": 1341116822711,
         "latitude": 37.7145347,
         "longitude": -122.172045
      },
      {
         "timestampMs": 1341116762906,
         "latitude": 37.7102683,
         "longitude": -122.1635084
      },
      {
         "timestampMs": 1341116162531,
         "latitude": 37.7005939,
         "longitude": -121.9878429
      },
      {
         "timestampMs": 1341116102525,
         "latitude": 37.6983855,
         "longitude": -121.9613508
      },
      {
         "timestampMs": 1341116042518,
         "latitude": 37.6986877,
         "longitude": -121.9445948
      },
      {
         "timestampMs": 1341115982507,
         "latitude": 37.7009708,
         "longitude": -121.9180308
      },
      {
         "timestampMs": 1341115922506,
         "latitude": 37.7015297,
         "longitude": -121.9000823
      },
      {
         "timestampMs": 1341115802289,
         "latitude": 37.7033943,
         "longitude": -121.8717036
      },
      {
         "timestampMs": 1341115741763,
         "latitude": 37.6949118,
         "longitude": -121.8540408
      },
      {
         "timestampMs": 1341115562027,
         "latitude": 37.700186,
         "longitude": -121.788232
      },
      {
         "timestampMs": 1341115384081,
         "latitude": 37.7057745,
         "longitude": -121.7317402
      },
      {
         "timestampMs": 1341115262122,
         "latitude": 37.7193135,
         "longitude": -121.6922671
      },
      {
         "timestampMs": 1341115141797,
         "latitude": 37.7206243,
         "longitude": -121.6646824
      },
      {
         "timestampMs": 1341115022709,
         "latitude": 37.7279997,
         "longitude": -121.6380038
      },
      {
         "timestampMs": 1341114961781,
         "latitude": 37.7383482,
         "longitude": -121.6012823
      },
      {
         "timestampMs": 1341114841764,
         "latitude": 37.7421552,
         "longitude": -121.5671542
      },
      {
         "timestampMs": 1341114661751,
         "latitude": 37.7230805,
         "longitude": -121.5366785
      },
      {
         "timestampMs": 1341114542968,
         "latitude": 37.7231221,
         "longitude": -121.4418758
      },
      {
         "timestampMs": 1341114361714,
         "latitude": 37.6685504,
         "longitude": -121.450762
      },
      {
         "timestampMs": 1341114181689,
         "latitude": 37.6448343,
         "longitude": -121.410782
      },
      {
         "timestampMs": 1341114104435,
         "latitude": 37.6379041,
         "longitude": -121.3524084
      },
      {
         "timestampMs": 1341114066529,
         "latitude": 37.6364534,
         "longitude": -121.3534842
      },
      {
         "timestampMs": 1341113938122,
         "latitude": 37.6380228,
         "longitude": -121.3048098
      },
      {
         "timestampMs": 1341113881557,
         "latitude": 37.6528232,
         "longitude": -121.3062653
      },
      {
         "timestampMs": 1341113761230,
         "latitude": 37.639499,
         "longitude": -121.248785
      },
      {
         "timestampMs": 1341113523259,
         "latitude": 37.7089967,
         "longitude": -121.1836872
      },
      {
         "timestampMs": 1341113401009,
         "latitude": 37.6382172,
         "longitude": -121.1808146
      },
      {
         "timestampMs": 1341113279640,
         "latitude": 37.6361398,
         "longitude": -121.104122
      },
      {
         "timestampMs": 1341113170246,
         "latitude": 37.6382174,
         "longitude": -121.070487
      },
      {
         "timestampMs": 1341113102178,
         "latitude": 37.621633,
         "longitude": -121.0523514
      },
      {
         "timestampMs": 1341112990185,
         "latitude": 37.6386315,
         "longitude": -121.0276599
      },
      {
         "timestampMs": 1341112921181,
         "latitude": 37.6384317,
         "longitude": -121.0288042
      },
      {
         "timestampMs": 1341112869475,
         "latitude": 37.6386345,
         "longitude": -121.0142917
      },
      {
         "timestampMs": 1341112801187,
         "latitude": 37.6386441,
         "longitude": -121.0208142
      },
      {
         "timestampMs": 1341112741142,
         "latitude": 37.6385206,
         "longitude": -121.0147453
      },
      {
         "timestampMs": 1341112689799,
         "latitude": 37.639426,
         "longitude": -121.0063855
      },
      {
         "timestampMs": 1341112629616,
         "latitude": 37.6375128,
         "longitude": -121.0033149
      },
      {
         "timestampMs": 1341112621774,
         "latitude": 37.6394299,
         "longitude": -121.0064294
      },
      {
         "timestampMs": 1341112569586,
         "latitude": 37.6338779,
         "longitude": -121.000806
      },
      {
         "timestampMs": 1341112509274,
         "latitude": 37.6253748,
         "longitude": -120.9947853
      },
      {
         "timestampMs": 1341112321115,
         "latitude": 37.6198067,
         "longitude": -120.9903913
      },
      {
         "timestampMs": 1341112208365,
         "latitude": 37.5964572,
         "longitude": -120.9623558
      },
      {
         "timestampMs": 1341112143410,
         "latitude": 37.5898566,
         "longitude": -120.9713714
      },
      {
         "timestampMs": 1341112029413,
         "latitude": 37.5391191,
         "longitude": -120.8944761
      },
      {
         "timestampMs": 1341112020934,
         "latitude": 37.5634949,
         "longitude": -120.9245299
      },
      {
         "timestampMs": 1341111909626,
         "latitude": 37.5231696,
         "longitude": -120.8845376
      },
      {
         "timestampMs": 1341111849557,
         "latitude": 37.494364,
         "longitude": -120.8698023
      },
      {
         "timestampMs": 1341111730117,
         "latitude": 37.4800082,
         "longitude": -120.8593941
      },
      {
         "timestampMs": 1341111720691,
         "latitude": 37.4955341,
         "longitude": -120.8709779
      },
      {
         "timestampMs": 1341111669587,
         "latitude": 37.4633021,
         "longitude": -120.8229177
      },
      {
         "timestampMs": 1341111660679,
         "latitude": 37.4764972,
         "longitude": -120.8508901
      },
      {
         "timestampMs": 1341111611066,
         "latitude": 37.455582,
         "longitude": -120.813762
      },
      {
         "timestampMs": 1341111491175,
         "latitude": 37.4566588,
         "longitude": -120.8157777
      },
      {
         "timestampMs": 1341111429292,
         "latitude": 37.4326231,
         "longitude": -120.778002
      },
      {
         "timestampMs": 1341111310306,
         "latitude": 37.3887053,
         "longitude": -120.7322933
      },
      {
         "timestampMs": 1341111188866,
         "latitude": 37.3887537,
         "longitude": -120.7360445
      },
      {
         "timestampMs": 1341110466551,
         "latitude": 37.3871665,
         "longitude": -120.7373839
      },
      {
         "timestampMs": 1341109926442,
         "latitude": 37.388754,
         "longitude": -120.7360425
      },
      {
         "timestampMs": 1341109617115,
         "latitude": 37.3871676,
         "longitude": -120.7373838
      },
      {
         "timestampMs": 1341109558611,
         "latitude": 37.3866109,
         "longitude": -120.7373111
      },
      {
         "timestampMs": 1341109317981,
         "latitude": 37.3884672,
         "longitude": -120.7362956
      },
      {
         "timestampMs": 1341109198037,
         "latitude": 37.3871665,
         "longitude": -120.7373839
      },
      {
         "timestampMs": 1341109079270,
         "latitude": 37.388753,
         "longitude": -120.7360428
      },
      {
         "timestampMs": 1341109017917,
         "latitude": 37.3866617,
         "longitude": -120.7373428
      },
      {
         "timestampMs": 1341108599162,
         "latitude": 37.3866112,
         "longitude": -120.7373093
      },
      {
         "timestampMs": 1341108058109,
         "latitude": 37.3685009,
         "longitude": -120.6697381
      },
      {
         "timestampMs": 1341107879614,
         "latitude": 37.3435019,
         "longitude": -120.6173131
      },
      {
         "timestampMs": 1341107759196,
         "latitude": 37.3429652,
         "longitude": -120.6094991
      },
      {
         "timestampMs": 1341107758180,
         "latitude": 37.3353475,
         "longitude": -120.5802303
      },
      {
         "timestampMs": 1341107701879,
         "latitude": 37.339905,
         "longitude": -120.5843657
      },
      {
         "timestampMs": 1341107639516,
         "latitude": 37.3243582,
         "longitude": -120.5419761
      },
      {
         "timestampMs": 1341107637755,
         "latitude": 37.3155598,
         "longitude": -120.525824
      },
      {
         "timestampMs": 1341107457941,
         "latitude": 37.2993409,
         "longitude": -120.4922109
      },
      {
         "timestampMs": 1341107399204,
         "latitude": 37.2961886,
         "longitude": -120.4801865
      },
      {
         "timestampMs": 1341107339179,
         "latitude": 37.2951565,
         "longitude": -120.4674825
      },
      {
         "timestampMs": 1341107219817,
         "latitude": 37.295156,
         "longitude": -120.460445
      },
      {
         "timestampMs": 1341107077389,
         "latitude": 37.2951573,
         "longitude": -120.4168661
      },
      {
         "timestampMs": 1341107042209,
         "latitude": 37.2757845,
         "longitude": -120.4266512
      },
      {
         "timestampMs": 1341106859041,
         "latitude": 37.2971992,
         "longitude": -120.3855646
      },
      {
         "timestampMs": 1341106716344,
         "latitude": 37.2951233,
         "longitude": -120.3233673
      },
      {
         "timestampMs": 1341106679428,
         "latitude": 37.2905564,
         "longitude": -120.3248505
      },
      {
         "timestampMs": 1341106657653,
         "latitude": 37.2950506,
         "longitude": -120.3232588
      },
      {
         "timestampMs": 1341106378740,
         "latitude": 37.2971992,
         "longitude": -120.3855646
      },
      {
         "timestampMs": 1341106342159,
         "latitude": 37.3070052,
         "longitude": -120.2895964
      },
      {
         "timestampMs": 1341106222137,
         "latitude": 37.2971992,
         "longitude": -120.3855646
      },
      {
         "timestampMs": 1341106162117,
         "latitude": 37.2633639,
         "longitude": -120.3203346
      },
      {
         "timestampMs": 1341105865012,
         "latitude": 37.291896,
         "longitude": -120.4923412
      },
      {
         "timestampMs": 1341104781643,
         "latitude": 37.4870306,
         "longitude": -119.9677139
      },
      {
         "timestampMs": 1341104671060,
         "latitude": 37.4971279,
         "longitude": -119.9732775
      },
      {
         "timestampMs": 1341093934571,
         "latitude": 37.7448536,
         "longitude": -119.60505
      },
      {
         "timestampMs": 1341078689319,
         "latitude": 37.2295286,
         "longitude": -120.2551047
      },
      {
         "timestampMs": 1341078095093,
         "latitude": 37.2901002,
         "longitude": -120.3254806
      },
      {
         "timestampMs": 1341077908824,
         "latitude": 37.2955697,
         "longitude": -120.3827182
      },
      {
         "timestampMs": 1341077728445,
         "latitude": 37.2952401,
         "longitude": -120.4498931
      },
      {
         "timestampMs": 1341077500505,
         "latitude": 37.2951583,
         "longitude": -120.4674822
      },
      {
         "timestampMs": 1341077319763,
         "latitude": 37.2980601,
         "longitude": -120.4896335
      },
      {
         "timestampMs": 1341077260365,
         "latitude": 37.3056548,
         "longitude": -120.5037586
      },
      {
         "timestampMs": 1341077139695,
         "latitude": 37.3157911,
         "longitude": -120.5195274
      },
      {
         "timestampMs": 1341076959984,
         "latitude": 37.3373221,
         "longitude": -120.5820332
      },
      {
         "timestampMs": 1341076840032,
         "latitude": 37.353215,
         "longitude": -120.6260966
      },
      {
         "timestampMs": 1341076660564,
         "latitude": 37.3818712,
         "longitude": -120.6960918
      },
      {
         "timestampMs": 1341076480593,
         "latitude": 37.3887537,
         "longitude": -120.7360445
      },
      {
         "timestampMs": 1341076419008,
         "latitude": 37.3866109,
         "longitude": -120.7373111
      },
      {
         "timestampMs": 1341076057696,
         "latitude": 37.3871959,
         "longitude": -120.7384498
      },
      {
         "timestampMs": 1341075938901,
         "latitude": 37.3866617,
         "longitude": -120.7373428
      },
      {
         "timestampMs": 1341075884230,
         "latitude": 37.3874233,
         "longitude": -120.7375422
      },
      {
         "timestampMs": 1341075639662,
         "latitude": 37.3870024,
         "longitude": -120.7376364
      },
      {
         "timestampMs": 1341065294082,
         "latitude": 37.8084003,
         "longitude": -122.4121546
      },
      {
         "timestampMs": 1341064934631,
         "latitude": 37.8084601,
         "longitude": -122.4122658
      },
      {
         "timestampMs": 1341062978748,
         "latitude": 37.7853316,
         "longitude": -122.4088336
      },
      {
         "timestampMs": 1341062918168,
         "latitude": 37.7844553,
         "longitude": -122.4099047
      },
      {
         "timestampMs": 1341062861436,
         "latitude": 37.7844378,
         "longitude": -122.4094994
      },
      {
         "timestampMs": 1341062798593,
         "latitude": 37.7839698,
         "longitude": -122.4128054
      },
      {
         "timestampMs": 1341062755138,
         "latitude": 37.780366,
         "longitude": -122.4126836
      },
      {
         "timestampMs": 1341062743379,
         "latitude": 37.7820518,
         "longitude": -122.4139667
      },
      {
         "timestampMs": 1341062618129,
         "latitude": 37.7811104,
         "longitude": -122.4121069
      },
      {
         "timestampMs": 1341062456197,
         "latitude": 37.7807632,
         "longitude": -122.4121386
      },
      {
         "timestampMs": 1341062313103,
         "latitude": 37.7807034,
         "longitude": -122.4121961
      },
      {
         "timestampMs": 1341062253118,
         "latitude": 37.7814709,
         "longitude": -122.4124072
      },
      {
         "timestampMs": 1341058652462,
         "latitude": 37.7814709,
         "longitude": -122.4124072
      },
      {
         "timestampMs": 1341057868235,
         "latitude": 37.7812637,
         "longitude": -122.4125604
      },
      {
         "timestampMs": 1341057840924,
         "latitude": 37.781812,
         "longitude": -122.4128272
      },
      {
         "timestampMs": 1341056731712,
         "latitude": 37.7814709,
         "longitude": -122.4124072
      },
      {
         "timestampMs": 1341056551483,
         "latitude": 37.7814709,
         "longitude": -122.4124072
      },
      {
         "timestampMs": 1341055710302,
         "latitude": 37.7814709,
         "longitude": -122.4124072
      },
      {
         "timestampMs": 1341055231110,
         "latitude": 37.7814709,
         "longitude": -122.4124072
      },
      {
         "timestampMs": 1341051629893,
         "latitude": 37.7814709,
         "longitude": -122.4124072
      },
      {
         "timestampMs": 1341051389822,
         "latitude": 37.7814709,
         "longitude": -122.4124072
      },
      {
         "timestampMs": 1341051089758,
         "latitude": 37.7814709,
         "longitude": -122.4124072
      },
      {
         "timestampMs": 1341050908834,
         "latitude": 37.7814709,
         "longitude": -122.4124072
      },
      {
         "timestampMs": 1341047307788,
         "latitude": 37.7814709,
         "longitude": -122.4124072
      },
      {
         "timestampMs": 1341046947027,
         "latitude": 37.7814354,
         "longitude": -122.4123777
      },
      {
         "timestampMs": 1341043291512,
         "latitude": 37.7814354,
         "longitude": -122.4123777
      },
      {
         "timestampMs": 1341039930451,
         "latitude": 37.7814292,
         "longitude": -122.4123774
      },
      {
         "timestampMs": 1341039870367,
         "latitude": 37.7814292,
         "longitude": -122.4123774
      },
      {
         "timestampMs": 1341039818662,
         "latitude": 37.7822259,
         "longitude": -122.4122561
      },
      {
         "timestampMs": 1341039809588,
         "latitude": 37.7814292,
         "longitude": -122.4123774
      },
      {
         "timestampMs": 1341039801693,
         "latitude": 37.780881,
         "longitude": -122.413344
      },
      {
         "timestampMs": 1341039780831,
         "latitude": 37.780881,
         "longitude": -122.413344
      },
      {
         "timestampMs": 1341036208312,
         "latitude": 37.7814292,
         "longitude": -122.4123774
      },
      {
         "timestampMs": 1341035729073,
         "latitude": 37.7814292,
         "longitude": -122.4123774
      },
      {
         "timestampMs": 1341035669078,
         "latitude": 37.7814292,
         "longitude": -122.4123774
      },
      {
         "timestampMs": 1341035608176,
         "latitude": 37.7814292,
         "longitude": -122.4123774
      },
      {
         "timestampMs": 1341032007043,
         "latitude": 37.7814292,
         "longitude": -122.4123774
      },
      {
         "timestampMs": 1341031647973,
         "latitude": 37.7811472,
         "longitude": -122.4121539
      },
      {
         "timestampMs": 1341027697993,
         "latitude": 37.7807801,
         "longitude": -122.4121737
      },
      {
         "timestampMs": 1341026917270,
         "latitude": 37.7814362,
         "longitude": -122.4123974
      },
      {
         "timestampMs": 1341026197084,
         "latitude": 37.7849664,
         "longitude": -122.4048859
      },
      {
         "timestampMs": 1341023619704,
         "latitude": 37.7805577,
         "longitude": -122.4124409
      },
      {
         "timestampMs": 1341021708726,
         "latitude": 37.7868048,
         "longitude": -122.4946087
      },
      {
         "timestampMs": 1341021691345,
         "latitude": 37.7864741,
         "longitude": -122.4947413
      },
      {
         "timestampMs": 1341018957882,
         "latitude": 37.7804515,
         "longitude": -122.4124036
      },
      {
         "timestampMs": 1341012773712,
         "latitude": 37.7804515,
         "longitude": -122.4124036
      },
      {
         "timestampMs": 1341009821856,
         "latitude": 37.7806883,
         "longitude": -122.4121649
      },
      {
         "timestampMs": 1341009556580,
         "latitude": 37.7815239,
         "longitude": -122.4123863
      },
      {
         "timestampMs": 1341008773253,
         "latitude": 37.7807788,
         "longitude": -122.4121628
      },
      {
         "timestampMs": 1341006052940,
         "latitude": 37.7791725,
         "longitude": -122.4155669
      },
      {
         "timestampMs": 1341003613829,
         "latitude": 37.780881,
         "longitude": -122.413344
      },
      {
         "timestampMs": 1341003191569,
         "latitude": 37.7791404,
         "longitude": -122.4155577
      },
      {
         "timestampMs": 1341002326102,
         "latitude": 37.7807667,
         "longitude": -122.4121431
      },
      {
         "timestampMs": 1341001845094,
         "latitude": 37.7807204,
         "longitude": -122.4121159
      },
      {
         "timestampMs": 1341001837352,
         "latitude": 37.7808142,
         "longitude": -122.4121699
      },
      {
         "timestampMs": 1341001776236,
         "latitude": 37.7804467,
         "longitude": -122.4125903
      },
      {
         "timestampMs": 1341001717045,
         "latitude": 37.7808538,
         "longitude": -122.4120533
      },
      {
         "timestampMs": 1341001684759,
         "latitude": 37.780881,
         "longitude": -122.413344
      },
      {
         "timestampMs": 1341001185465,
         "latitude": 37.7849664,
         "longitude": -122.4048859
      },
      {
         "timestampMs": 1341000574887,
         "latitude": 37.7832469,
         "longitude": -122.4034427
      },
      {
         "timestampMs": 1340997751234,
         "latitude": 37.7861776,
         "longitude": -122.4100326
      },
      {
         "timestampMs": 1340996909370,
         "latitude": 37.7861772,
         "longitude": -122.4100328
      },
      {
         "timestampMs": 1340996262312,
         "latitude": 37.783819,
         "longitude": -122.403242
      },
      {
         "timestampMs": 1340995842650,
         "latitude": 37.7833424,
         "longitude": -122.4034285
      },
      {
         "timestampMs": 1340995688219,
         "latitude": 37.7833644,
         "longitude": -122.4035277
      },
      {
         "timestampMs": 1340993966728,
         "latitude": 37.783819,
         "longitude": -122.403242
      },
      {
         "timestampMs": 1340993907960,
         "latitude": 37.7840233,
         "longitude": -122.403869
      },
      {
         "timestampMs": 1340993253875,
         "latitude": 37.7840233,
         "longitude": -122.403869
      },
      {
         "timestampMs": 1340993139467,
         "latitude": 37.7845687,
         "longitude": -122.4034886
      },
      {
         "timestampMs": 1340992643255,
         "latitude": 37.7840233,
         "longitude": -122.403869
      },
      {
         "timestampMs": 1340992307259,
         "latitude": 37.8071441,
         "longitude": -122.4209946
      },
      {
         "timestampMs": 1340990806809,
         "latitude": 37.7840233,
         "longitude": -122.403869
      },
      {
         "timestampMs": 1340990686815,
         "latitude": 37.7840233,
         "longitude": -122.403869
      },
      {
         "timestampMs": 1340987047446,
         "latitude": 37.7836206,
         "longitude": -122.4035123
      },
      {
         "timestampMs": 1340986927346,
         "latitude": 37.7840233,
         "longitude": -122.403869
      },
      {
         "timestampMs": 1340985555744,
         "latitude": 37.78399,
         "longitude": -122.401316
      },
      {
         "timestampMs": 1340985489585,
         "latitude": 37.7715825,
         "longitude": -122.4042117
      },
      {
         "timestampMs": 1340985429616,
         "latitude": 37.7842421,
         "longitude": -122.4030317
      },
      {
         "timestampMs": 1340985009144,
         "latitude": 37.7842421,
         "longitude": -122.4030317
      },
      {
         "timestampMs": 1340984589254,
         "latitude": 37.7838787,
         "longitude": -122.4037875
      },
      {
         "timestampMs": 1340984469509,
         "latitude": 37.7839435,
         "longitude": -122.4036927
      },
      {
         "timestampMs": 1340983269863,
         "latitude": 37.8071448,
         "longitude": -122.4209946
      },
      {
         "timestampMs": 1340983208722,
         "latitude": 37.7952793,
         "longitude": -122.4046898
      },
      {
         "timestampMs": 1340983148855,
         "latitude": 37.7839279,
         "longitude": -122.4039671
      },
      {
         "timestampMs": 1340982710596,
         "latitude": 37.8071445,
         "longitude": -122.4209947
      },
      {
         "timestampMs": 1340981947280,
         "latitude": 37.7839279,
         "longitude": -122.4039671
      },
      {
         "timestampMs": 1340981325893,
         "latitude": 37.7949681,
         "longitude": -122.4054849
      },
      {
         "timestampMs": 1340981266983,
         "latitude": 37.7839279,
         "longitude": -122.4039671
      },
      {
         "timestampMs": 1340981097611,
         "latitude": 37.7834189,
         "longitude": -122.4029435
      },
      {
         "timestampMs": 1340981026297,
         "latitude": 37.7833996,
         "longitude": -122.4030598
      },
      {
         "timestampMs": 1340979896041,
         "latitude": 37.7803454,
         "longitude": -122.4126705
      },
      {
         "timestampMs": 1340979706171,
         "latitude": 37.7806864,
         "longitude": -122.4122564
      },
      {
         "timestampMs": 1340978805149,
         "latitude": 37.7813941,
         "longitude": -122.4123531
      },
      {
         "timestampMs": 1340976644885,
         "latitude": 37.7814399,
         "longitude": -122.4123894
      },
      {
         "timestampMs": 1340976584878,
         "latitude": 37.7814399,
         "longitude": -122.4123894
      },
      {
         "timestampMs": 1340972982199,
         "latitude": 37.7814399,
         "longitude": -122.4123894
      },
      {
         "timestampMs": 1340965830621,
         "latitude": 37.7805992,
         "longitude": -122.4123736
      },
      {
         "timestampMs": 1340962229532,
         "latitude": 37.781443,
         "longitude": -122.41237
      },
      {
         "timestampMs": 1340962169516,
         "latitude": 37.7801895,
         "longitude": -122.4123338
      },
      {
         "timestampMs": 1340962109532,
         "latitude": 37.7801895,
         "longitude": -122.4123338
      },
      {
         "timestampMs": 1340958502208,
         "latitude": 37.7814295,
         "longitude": -122.412378
      },
      {
         "timestampMs": 1340956358284,
         "latitude": 37.7804327,
         "longitude": -122.4123727
      },
      {
         "timestampMs": 1340954633809,
         "latitude": 37.7814447,
         "longitude": -122.412417
      },
      {
         "timestampMs": 1340953553107,
         "latitude": 37.7817835,
         "longitude": -122.412165
      },
      {
         "timestampMs": 1340953494797,
         "latitude": 37.7814399,
         "longitude": -122.4123894
      },
      {
         "timestampMs": 1340953434194,
         "latitude": 37.7815725,
         "longitude": -122.4122631
      },
      {
         "timestampMs": 1340952533384,
         "latitude": 37.7807444,
         "longitude": -122.4121496
      },
      {
         "timestampMs": 1340951993247,
         "latitude": 37.7807828,
         "longitude": -122.4121427
      },
      {
         "timestampMs": 1340949325176,
         "latitude": 37.780751,
         "longitude": -122.412114
      },
      {
         "timestampMs": 1340948344260,
         "latitude": 37.7807565,
         "longitude": -122.41214
      },
      {
         "timestampMs": 1340945722289,
         "latitude": 37.7807663,
         "longitude": -122.4121364
      },
      {
         "timestampMs": 1340944900000,
         "latitude": 37.780981,
         "longitude": -122.412701
      },
      {
         "timestampMs": 1340944741733,
         "latitude": 37.7807606,
         "longitude": -122.4121421
      },
      {
         "timestampMs": 1340943085484,
         "latitude": 37.7810274,
         "longitude": -122.412281
      },
      {
         "timestampMs": 1340943025483,
         "latitude": 37.7805199,
         "longitude": -122.4126013
      },
      {
         "timestampMs": 1340942245124,
         "latitude": 37.7807339,
         "longitude": -122.4122438
      },
      {
         "timestampMs": 1340942106252,
         "latitude": 37.7807161,
         "longitude": -122.4121748
      },
      {
         "timestampMs": 1340940504196,
         "latitude": 37.7814831,
         "longitude": -122.4123473
      },
      {
         "timestampMs": 1340939544032,
         "latitude": 37.779625,
         "longitude": -122.413417
      },
      {
         "timestampMs": 1340939303907,
         "latitude": 37.784083,
         "longitude": -122.408314
      },
      {
         "timestampMs": 1340939003708,
         "latitude": 37.7839776,
         "longitude": -122.4077448
      },
      {
         "timestampMs": 1340938643676,
         "latitude": 37.7852581,
         "longitude": -122.4064853
      },
      {
         "timestampMs": 1340938523650,
         "latitude": 37.7849993,
         "longitude": -122.4048179
      },
      {
         "timestampMs": 1340935023237,
         "latitude": 37.7841951,
         "longitude": -122.4046729
      },
      {
         "timestampMs": 1340930089896,
         "latitude": 37.783608,
         "longitude": -122.403479
      },
      {
         "timestampMs": 1340929369610,
         "latitude": 37.7844781,
         "longitude": -122.4036214
      },
      {
         "timestampMs": 1340926358738,
         "latitude": 37.783819,
         "longitude": -122.403242
      },
      {
         "timestampMs": 1340925030612,
         "latitude": 37.783608,
         "longitude": -122.4034794
      },
      {
         "timestampMs": 1340923750748,
         "latitude": 37.7831572,
         "longitude": -122.403524
      },
      {
         "timestampMs": 1340923329250,
         "latitude": 37.783819,
         "longitude": -122.403242
      },
      {
         "timestampMs": 1340922909861,
         "latitude": 37.783819,
         "longitude": -122.403242
      },
      {
         "timestampMs": 1340922848749,
         "latitude": 37.7840233,
         "longitude": -122.403869
      },
      {
         "timestampMs": 1340922429998,
         "latitude": 37.7868683,
         "longitude": -122.4021359
      },
      {
         "timestampMs": 1340921569885,
         "latitude": 37.783819,
         "longitude": -122.403242
      },
      {
         "timestampMs": 1340918302495,
         "latitude": 37.7834174,
         "longitude": -122.4028515
      },
      {
         "timestampMs": 1340917582623,
         "latitude": 37.783608,
         "longitude": -122.403479
      },
      {
         "timestampMs": 1340915050922,
         "latitude": 37.7839921,
         "longitude": -122.4038268
      },
      {
         "timestampMs": 1340914331644,
         "latitude": 37.7854094,
         "longitude": -122.406386
      },
      {
         "timestampMs": 1340913011297,
         "latitude": 37.7840233,
         "longitude": -122.403869
      },
      {
         "timestampMs": 1340912891652,
         "latitude": 37.7840233,
         "longitude": -122.403869
      },
      {
         "timestampMs": 1340911210531,
         "latitude": 37.7834174,
         "longitude": -122.4028515
      },
      {
         "timestampMs": 1340911090243,
         "latitude": 37.7765745,
         "longitude": -122.3967387
      },
      {
         "timestampMs": 1340910910446,
         "latitude": 37.7834174,
         "longitude": -122.4028515
      },
      {
         "timestampMs": 1340910670222,
         "latitude": 37.7766331,
         "longitude": -122.3967918
      },
      {
         "timestampMs": 1340909089902,
         "latitude": 37.7838269,
         "longitude": -122.4026251
      },
      {
         "timestampMs": 1340909029850,
         "latitude": 37.783819,
         "longitude": -122.403242
      },
      {
         "timestampMs": 1340908307438,
         "latitude": 37.7850819,
         "longitude": -122.4049025
      },
      {
         "timestampMs": 1340907347042,
         "latitude": 37.7857931,
         "longitude": -122.4125158
      },
      {
         "timestampMs": 1340906686844,
         "latitude": 37.7850336,
         "longitude": -122.4054201
      },
      {
         "timestampMs": 1340905666358,
         "latitude": 37.7838324,
         "longitude": -122.4034671
      },
      {
         "timestampMs": 1340904886121,
         "latitude": 37.7860461,
         "longitude": -122.4131446
      },
      {
         "timestampMs": 1340904765919,
         "latitude": 37.7850232,
         "longitude": -122.4054293
      },
      {
         "timestampMs": 1340903445507,
         "latitude": 37.7838629,
         "longitude": -122.4034918
      },
      {
         "timestampMs": 1340903265346,
         "latitude": 37.7849908,
         "longitude": -122.4053657
      },
      {
         "timestampMs": 1340903204375,
         "latitude": 37.7839934,
         "longitude": -122.4036686
      },
      {
         "timestampMs": 1340903085377,
         "latitude": 37.7850217,
         "longitude": -122.4054313
      },
      {
         "timestampMs": 1340903025378,
         "latitude": 37.7838555,
         "longitude": -122.4034939
      },
      {
         "timestampMs": 1340902905332,
         "latitude": 37.7849896,
         "longitude": -122.4053681
      },
      {
         "timestampMs": 1340902844298,
         "latitude": 37.7840136,
         "longitude": -122.4036937
      },
      {
         "timestampMs": 1340900144065,
         "latitude": 37.7842139,
         "longitude": -122.4041887
      },
      {
         "timestampMs": 1340898494461,
         "latitude": 37.7832469,
         "longitude": -122.4034427
      },
      {
         "timestampMs": 1340897653273,
         "latitude": 37.783706,
         "longitude": -122.4033638
      },
      {
         "timestampMs": 1340897593251,
         "latitude": 37.7842275,
         "longitude": -122.4042142
      },
      {
         "timestampMs": 1340897533213,
         "latitude": 37.7834177,
         "longitude": -122.4031252
      },
      {
         "timestampMs": 1340897353203,
         "latitude": 37.7839347,
         "longitude": -122.4038105
      },
      {
         "timestampMs": 1340897003385,
         "latitude": 37.783312,
         "longitude": -122.4033107
      },
      {
         "timestampMs": 1340896823331,
         "latitude": 37.7858202,
         "longitude": -122.4115369
      },
      {
         "timestampMs": 1340896763286,
         "latitude": 37.7849761,
         "longitude": -122.4061929
      },
      {
         "timestampMs": 1340896643280,
         "latitude": 37.783418,
         "longitude": -122.4031261
      },
      {
         "timestampMs": 1340896583682,
         "latitude": 37.7849761,
         "longitude": -122.4061929
      },
      {
         "timestampMs": 1340896404691,
         "latitude": 37.786429,
         "longitude": -122.411559
      },
      {
         "timestampMs": 1340894679744,
         "latitude": 37.807145,
         "longitude": -122.420991
      },
      {
         "timestampMs": 1340894612205,
         "latitude": 37.7844227,
         "longitude": -122.4035268
      },
      {
         "timestampMs": 1340894493998,
         "latitude": 37.8071445,
         "longitude": -122.4209947
      },
      {
         "timestampMs": 1340894432169,
         "latitude": 37.789931,
         "longitude": -122.4098196
      },
      {
         "timestampMs": 1340894012198,
         "latitude": 37.7952813,
         "longitude": -122.4046894
      },
      {
         "timestampMs": 1340893832079,
         "latitude": 37.7844227,
         "longitude": -122.4035268
      },
      {
         "timestampMs": 1340893351931,
         "latitude": 37.7833747,
         "longitude": -122.4028895
      },
      {
         "timestampMs": 1340892330881,
         "latitude": 37.7852415,
         "longitude": -122.4052011
      },
      {
         "timestampMs": 1340892270812,
         "latitude": 37.7856395,
         "longitude": -122.4056765
      },
      {
         "timestampMs": 1340892150888,
         "latitude": 37.7841463,
         "longitude": -122.408109
      },
      {
         "timestampMs": 1340892090785,
         "latitude": 37.7813226,
         "longitude": -122.411716
      },
      {
         "timestampMs": 1340891911177,
         "latitude": 37.780341,
         "longitude": -122.4126716
      },
      {
         "timestampMs": 1340891850595,
         "latitude": 37.7810146,
         "longitude": -122.4122358
      },
      {
         "timestampMs": 1340890884841,
         "latitude": 37.7815028,
         "longitude": -122.4124025
      },
      {
         "timestampMs": 1340889085013,
         "latitude": 37.7814839,
         "longitude": -122.4123237
      },
      {
         "timestampMs": 1340888965000,
         "latitude": 37.7814839,
         "longitude": -122.4123237
      },
      {
         "timestampMs": 1340885363724,
         "latitude": 37.7814839,
         "longitude": -122.4123237
      },
      {
         "timestampMs": 1340885243786,
         "latitude": 37.7814839,
         "longitude": -122.4123237
      },
      {
         "timestampMs": 1340883202850,
         "latitude": 37.7814839,
         "longitude": -122.4123237
      },
      {
         "timestampMs": 1340883142852,
         "latitude": 37.7814839,
         "longitude": -122.4123237
      },
      {
         "timestampMs": 1340879541063,
         "latitude": 37.7814839,
         "longitude": -122.4123237
      },
      {
         "timestampMs": 1340879481068,
         "latitude": 37.7814839,
         "longitude": -122.4123237
      },
      {
         "timestampMs": 1340875879194,
         "latitude": 37.7814839,
         "longitude": -122.4123237
      },
      {
         "timestampMs": 1340875399110,
         "latitude": 37.7814839,
         "longitude": -122.4123237
      },
      {
         "timestampMs": 1340875338219,
         "latitude": 37.7814839,
         "longitude": -122.4123237
      },
      {
         "timestampMs": 1340871532868,
         "latitude": 37.7814839,
         "longitude": -122.4123237
      },
      {
         "timestampMs": 1340869972172,
         "latitude": 37.7814839,
         "longitude": -122.4123237
      },
      {
         "timestampMs": 1340869191674,
         "latitude": 37.7814839,
         "longitude": -122.4123237
      },
      {
         "timestampMs": 1340868711379,
         "latitude": 37.7814839,
         "longitude": -122.4123237
      },
      {
         "timestampMs": 1340868651377,
         "latitude": 37.7814839,
         "longitude": -122.4123237
      },
      {
         "timestampMs": 1340865048951,
         "latitude": 37.7814839,
         "longitude": -122.4123237
      },
      {
         "timestampMs": 1340862938671,
         "latitude": 37.7805262,
         "longitude": -122.4125862
      },
      {
         "timestampMs": 1340862294338,
         "latitude": 37.7809706,
         "longitude": -122.4121771
      },
      {
         "timestampMs": 1340861874212,
         "latitude": 37.785714,
         "longitude": -122.4055776
      },
      {
         "timestampMs": 1340861454148,
         "latitude": 37.7845226,
         "longitude": -122.4041889
      },
      {
         "timestampMs": 1340861393069,
         "latitude": 37.7838647,
         "longitude": -122.4030591
      },
      {
         "timestampMs": 1340861213424,
         "latitude": 37.7836978,
         "longitude": -122.4030609
      },
      {
         "timestampMs": 1340860158415,
         "latitude": 37.783198,
         "longitude": -122.4038934
      },
      {
         "timestampMs": 1340859794078,
         "latitude": 37.7843117,
         "longitude": -122.4030968
      },
      {
         "timestampMs": 1340859375877,
         "latitude": 37.7837109,
         "longitude": -122.4033928
      },
      {
         "timestampMs": 1340859014574,
         "latitude": 37.7837109,
         "longitude": -122.4033928
      },
      {
         "timestampMs": 1340858833487,
         "latitude": 37.7837109,
         "longitude": -122.4033928
      },
      {
         "timestampMs": 1340858473988,
         "latitude": 37.7837109,
         "longitude": -122.4033928
      },
      {
         "timestampMs": 1340857270211,
         "latitude": 37.7837109,
         "longitude": -122.4033928
      },
      {
         "timestampMs": 1340856790052,
         "latitude": 37.7837109,
         "longitude": -122.4033928
      },
      {
         "timestampMs": 1340856369932,
         "latitude": 37.783613,
         "longitude": -122.4025672
      },
      {
         "timestampMs": 1340856309848,
         "latitude": 37.7837109,
         "longitude": -122.4033928
      },
      {
         "timestampMs": 1340856009759,
         "latitude": 37.7837109,
         "longitude": -122.4033928
      },
      {
         "timestampMs": 1340855710559,
         "latitude": 37.7836124,
         "longitude": -122.402567
      },
      {
         "timestampMs": 1340855589568,
         "latitude": 37.7859842,
         "longitude": -122.4046468
      },
      {
         "timestampMs": 1340855470676,
         "latitude": 37.7836129,
         "longitude": -122.402567
      },
      {
         "timestampMs": 1340855410545,
         "latitude": 37.7859842,
         "longitude": -122.4046468
      },
      {
         "timestampMs": 1340855109889,
         "latitude": 37.7836145,
         "longitude": -122.4025666
      },
      {
         "timestampMs": 1340855064722,
         "latitude": 37.7842689,
         "longitude": -122.4030596
      },
      {
         "timestampMs": 1340855004666,
         "latitude": 37.7850336,
         "longitude": -122.4054201
      },
      {
         "timestampMs": 1340854464643,
         "latitude": 37.7843572,
         "longitude": -122.4030172
      },
      {
         "timestampMs": 1340854226713,
         "latitude": 37.7837109,
         "longitude": -122.4033928
      },
      {
         "timestampMs": 1340854044433,
         "latitude": 37.7837109,
         "longitude": -122.4033928
      },
      {
         "timestampMs": 1340853924318,
         "latitude": 37.7859842,
         "longitude": -122.4046468
      },
      {
         "timestampMs": 1340852424388,
         "latitude": 37.7843588,
         "longitude": -122.4030385
      },
      {
         "timestampMs": 1340852363608,
         "latitude": 37.7836126,
         "longitude": -122.4025669
      },
      {
         "timestampMs": 1340852305563,
         "latitude": 37.7837109,
         "longitude": -122.4033928
      },
      {
         "timestampMs": 1340851819317,
         "latitude": 37.7721664,
         "longitude": -122.4034197
      },
      {
         "timestampMs": 1340851399140,
         "latitude": 37.7847013,
         "longitude": -122.4042602
      },
      {
         "timestampMs": 1340850618875,
         "latitude": 37.7721664,
         "longitude": -122.4034193
      },
      {
         "timestampMs": 1340850381225,
         "latitude": 37.7863437,
         "longitude": -122.4110229
      },
      {
         "timestampMs": 1340849837046,
         "latitude": 37.7721666,
         "longitude": -122.403418
      },
      {
         "timestampMs": 1340849538398,
         "latitude": 37.786342,
         "longitude": -122.4110242
      },
      {
         "timestampMs": 1340848149529,
         "latitude": 37.7823173,
         "longitude": -122.4041053
      },
      {
         "timestampMs": 1340846528266,
         "latitude": 37.7850206,
         "longitude": -122.4054306
      },
      {
         "timestampMs": 1340845266392,
         "latitude": 37.7831314,
         "longitude": -122.4036403
      },
      {
         "timestampMs": 1340845148308,
         "latitude": 37.7851179,
         "longitude": -122.4050395
      },
      {
         "timestampMs": 1340845086340,
         "latitude": 37.7854908,
         "longitude": -122.4058311
      },
      {
         "timestampMs": 1340845026331,
         "latitude": 37.7852281,
         "longitude": -122.406501
      },
      {
         "timestampMs": 1340844906792,
         "latitude": 37.7840739,
         "longitude": -122.4081045
      },
      {
         "timestampMs": 1340844780882,
         "latitude": 37.7826505,
         "longitude": -122.4096477
      },
      {
         "timestampMs": 1340844718184,
         "latitude": 37.7818785,
         "longitude": -122.4111635
      },
      {
         "timestampMs": 1340844659127,
         "latitude": 37.7810599,
         "longitude": -122.4120169
      },
      {
         "timestampMs": 1340844479059,
         "latitude": 37.780356,
         "longitude": -122.4126415
      },
      {
         "timestampMs": 1340843757414,
         "latitude": 37.7814509,
         "longitude": -122.4124315
      },
      {
         "timestampMs": 1340842918247,
         "latitude": 37.7811496,
         "longitude": -122.4120451
      },
      {
         "timestampMs": 1340842798083,
         "latitude": 37.7819141,
         "longitude": -122.411115
      },
      {
         "timestampMs": 1340842738040,
         "latitude": 37.7822415,
         "longitude": -122.4101495
      },
      {
         "timestampMs": 1340842617890,
         "latitude": 37.7840787,
         "longitude": -122.4082699
      },
      {
         "timestampMs": 1340842497807,
         "latitude": 37.7835788,
         "longitude": -122.4074581
      },
      {
         "timestampMs": 1340842380727,
         "latitude": 37.7826248,
         "longitude": -122.4062903
      },
      {
         "timestampMs": 1340842140103,
         "latitude": 37.7832755,
         "longitude": -122.4030169
      },
      {
         "timestampMs": 1340841492722,
         "latitude": 37.7837836,
         "longitude": -122.4031655
      },
      {
         "timestampMs": 1340840891654,
         "latitude": 37.7855311,
         "longitude": -122.4099464
      },
      {
         "timestampMs": 1340839631200,
         "latitude": 37.7835483,
         "longitude": -122.4033794
      },
      {
         "timestampMs": 1340839333964,
         "latitude": 37.7776185,
         "longitude": -122.4045993
      },
      {
         "timestampMs": 1340839272085,
         "latitude": 37.7849761,
         "longitude": -122.4061929
      },
      {
         "timestampMs": 1340839170732,
         "latitude": 37.7841159,
         "longitude": -122.403785
      },
      {
         "timestampMs": 1340838492787,
         "latitude": 37.7842421,
         "longitude": -122.4030317
      },
      {
         "timestampMs": 1340838250996,
         "latitude": 37.7832694,
         "longitude": -122.4036623
      },
      {
         "timestampMs": 1340838070217,
         "latitude": 37.7719343,
         "longitude": -122.4039631
      },
      {
         "timestampMs": 1340837899735,
         "latitude": 37.7831921,
         "longitude": -122.4032284
      },
      {
         "timestampMs": 1340837589079,
         "latitude": 37.7836081,
         "longitude": -122.4034785
      },
      {
         "timestampMs": 1340836930296,
         "latitude": 37.7834174,
         "longitude": -122.4028515
      },
      {
         "timestampMs": 1340835785806,
         "latitude": 37.7834174,
         "longitude": -122.4028515
      },
      {
         "timestampMs": 1340833719993,
         "latitude": 37.7830539,
         "longitude": -122.4034676
      },
      {
         "timestampMs": 1340833339333,
         "latitude": 37.7835214,
         "longitude": -122.4036904
      },
      {
         "timestampMs": 1340832462015,
         "latitude": 37.783757,
         "longitude": -122.4029664
      },
      {
         "timestampMs": 1340829622230,
         "latitude": 37.7836589,
         "longitude": -122.4026814
      },
      {
         "timestampMs": 1340829306031,
         "latitude": 37.78399,
         "longitude": -122.401316
      },
      {
         "timestampMs": 1340826413753,
         "latitude": 37.7836951,
         "longitude": -122.4026998
      },
      {
         "timestampMs": 1340824126857,
         "latitude": 37.7834821,
         "longitude": -122.40357
      },
      {
         "timestampMs": 1340823619000,
         "latitude": 37.78399,
         "longitude": -122.401316
      },
      {
         "timestampMs": 1340823405514,
         "latitude": 37.7835343,
         "longitude": -122.4031477
      },
      {
         "timestampMs": 1340822630007,
         "latitude": 37.7849888,
         "longitude": -122.4053858
      },
      {
         "timestampMs": 1340822262727,
         "latitude": 37.7837155,
         "longitude": -122.4034063
      },
      {
         "timestampMs": 1340822142696,
         "latitude": 37.7849938,
         "longitude": -122.405421
      },
      {
         "timestampMs": 1340822083694,
         "latitude": 37.7837583,
         "longitude": -122.4033649
      },
      {
         "timestampMs": 1340822023682,
         "latitude": 37.7850177,
         "longitude": -122.4054118
      },
      {
         "timestampMs": 1340821963645,
         "latitude": 37.7837187,
         "longitude": -122.4033938
      },
      {
         "timestampMs": 1340821783007,
         "latitude": 37.7850179,
         "longitude": -122.4054117
      },
      {
         "timestampMs": 1340821602523,
         "latitude": 37.7837326,
         "longitude": -122.403341
      },
      {
         "timestampMs": 1340821483505,
         "latitude": 37.7850174,
         "longitude": -122.4054118
      },
      {
         "timestampMs": 1340821123187,
         "latitude": 37.7836743,
         "longitude": -122.4032427
      },
      {
         "timestampMs": 1340819082325,
         "latitude": 37.7849879,
         "longitude": -122.4053891
      },
      {
         "timestampMs": 1340818055530,
         "latitude": 37.7836785,
         "longitude": -122.4032184
      },
      {
         "timestampMs": 1340817815456,
         "latitude": 37.7839954,
         "longitude": -122.403668
      },
      {
         "timestampMs": 1340817754528,
         "latitude": 37.7850217,
         "longitude": -122.4054315
      },
      {
         "timestampMs": 1340817575096,
         "latitude": 37.7838019,
         "longitude": -122.4034242
      },
      {
         "timestampMs": 1340817455268,
         "latitude": 37.7849671,
         "longitude": -122.4053359
      },
      {
         "timestampMs": 1340817395256,
         "latitude": 37.7839282,
         "longitude": -122.4036003
      },
      {
         "timestampMs": 1340816855659,
         "latitude": 37.7850177,
         "longitude": -122.4054118
      },
      {
         "timestampMs": 1340816133524,
         "latitude": 37.7836752,
         "longitude": -122.4032392
      },
      {
         "timestampMs": 1340815789273,
         "latitude": 37.7850174,
         "longitude": -122.405412
      },
      {
         "timestampMs": 1340815714301,
         "latitude": 37.783994,
         "longitude": -122.4036671
      },
      {
         "timestampMs": 1340815296973,
         "latitude": 37.7839934,
         "longitude": -122.4036684
      },
      {
         "timestampMs": 1340814468264,
         "latitude": 37.7835794,
         "longitude": -122.4029899
      },
      {
         "timestampMs": 1340812464109,
         "latitude": 37.7841159,
         "longitude": -122.403785
      },
      {
         "timestampMs": 1340812017136,
         "latitude": 37.78399,
         "longitude": -122.401316
      },
      {
         "timestampMs": 1340811924000,
         "latitude": 37.771999,
         "longitude": -122.4038066
      },
      {
         "timestampMs": 1340811383786,
         "latitude": 37.7863257,
         "longitude": -122.410513
      },
      {
         "timestampMs": 1340811203815,
         "latitude": 37.7842141,
         "longitude": -122.4041887
      },
      {
         "timestampMs": 1340811143778,
         "latitude": 37.7854103,
         "longitude": -122.4029261
      },
      {
         "timestampMs": 1340810607306,
         "latitude": 37.7842139,
         "longitude": -122.4041887
      },
      {
         "timestampMs": 1340810070515,
         "latitude": 37.786006,
         "longitude": -122.4110783
      },
      {
         "timestampMs": 1340810005956,
         "latitude": 37.8071444,
         "longitude": -122.4209949
      },
      {
         "timestampMs": 1340809202419,
         "latitude": 37.783246,
         "longitude": -122.4034422
      },
      {
         "timestampMs": 1340809022025,
         "latitude": 37.7840435,
         "longitude": -122.4036623
      },
      {
         "timestampMs": 1340808664108,
         "latitude": 37.7850114,
         "longitude": -122.4022722
      },
      {
         "timestampMs": 1340808420997,
         "latitude": 37.7879487,
         "longitude": -122.4104372
      },
      {
         "timestampMs": 1340808302493,
         "latitude": 37.8071457,
         "longitude": -122.4209951
      },
      {
         "timestampMs": 1340808182743,
         "latitude": 37.7880789,
         "longitude": -122.4104508
      },
      {
         "timestampMs": 1340808094000,
         "latitude": 37.78399,
         "longitude": -122.401316
      },
      {
         "timestampMs": 1340807459734,
         "latitude": 37.7836123,
         "longitude": -122.4032338
      },
      {
         "timestampMs": 1340807100596,
         "latitude": 37.785074,
         "longitude": -122.4051026
      },
      {
         "timestampMs": 1340806980548,
         "latitude": 37.7853549,
         "longitude": -122.4064563
      },
      {
         "timestampMs": 1340806860470,
         "latitude": 37.7840836,
         "longitude": -122.4082441
      },
      {
         "timestampMs": 1340806800444,
         "latitude": 37.7816586,
         "longitude": -122.4110199
      },
      {
         "timestampMs": 1340806500438,
         "latitude": 37.7804309,
         "longitude": -122.412691
      },
      {
         "timestampMs": 1340803409141,
         "latitude": 37.7814188,
         "longitude": -122.4124067
      },
      {
         "timestampMs": 1340802869024,
         "latitude": 37.7814188,
         "longitude": -122.4124067
      },
      {
         "timestampMs": 1340802688959,
         "latitude": 37.7814188,
         "longitude": -122.4124067
      },
      {
         "timestampMs": 1340802628963,
         "latitude": 37.7814188,
         "longitude": -122.4124067
      },
      {
         "timestampMs": 1340799027342,
         "latitude": 37.7814188,
         "longitude": -122.4124067
      },
      {
         "timestampMs": 1340798427226,
         "latitude": 37.7814188,
         "longitude": -122.4124067
      },
      {
         "timestampMs": 1340794825995,
         "latitude": 37.7814188,
         "longitude": -122.4124067
      },
      {
         "timestampMs": 1340793384436,
         "latitude": 37.7814188,
         "longitude": -122.4124067
      },
      {
         "timestampMs": 1340793265304,
         "latitude": 37.7814188,
         "longitude": -122.4124067
      },
      {
         "timestampMs": 1340789664094,
         "latitude": 37.7814188,
         "longitude": -122.4124067
      },
      {
         "timestampMs": 1340788882886,
         "latitude": 37.7814343,
         "longitude": -122.4123791
      },
      {
         "timestampMs": 1340785242242,
         "latitude": 37.7814343,
         "longitude": -122.4123791
      },
      {
         "timestampMs": 1340785182236,
         "latitude": 37.7814343,
         "longitude": -122.4123791
      },
      {
         "timestampMs": 1340785122317,
         "latitude": 37.7814343,
         "longitude": -122.4123791
      },
      {
         "timestampMs": 1340781521105,
         "latitude": 37.7814343,
         "longitude": -122.4123791
      },
      {
         "timestampMs": 1340780319720,
         "latitude": 37.7816137,
         "longitude": -122.4118624
      },
      {
         "timestampMs": 1340779899091,
         "latitude": 37.781431,
         "longitude": -122.4124334
      },
      {
         "timestampMs": 1340778518149,
         "latitude": 37.7809533,
         "longitude": -122.4121651
      },
      {
         "timestampMs": 1340778398125,
         "latitude": 37.7826019,
         "longitude": -122.4102997
      },
      {
         "timestampMs": 1340778282423,
         "latitude": 37.7841557,
         "longitude": -122.4081236
      },
      {
         "timestampMs": 1340778217265,
         "latitude": 37.7852942,
         "longitude": -122.4063924
      },
      {
         "timestampMs": 1340778157131,
         "latitude": 37.7857161,
         "longitude": -122.4056184
      },
      {
         "timestampMs": 1340777917089,
         "latitude": 37.788006,
         "longitude": -122.4032278
      },
      {
         "timestampMs": 1340777643910,
         "latitude": 37.7885124,
         "longitude": -122.4032524
      },
      {
         "timestampMs": 1340777642275,
         "latitude": 37.7877246,
         "longitude": -122.4032791
      },
      {
         "timestampMs": 1340777501084,
         "latitude": 37.7866247,
         "longitude": -122.4024232
      },
      {
         "timestampMs": 1340777017200,
         "latitude": 37.7865148,
         "longitude": -122.4018025
      },
      {
         "timestampMs": 1340775636720,
         "latitude": 37.7865239,
         "longitude": -122.4017847
      },
      {
         "timestampMs": 1340772008357,
         "latitude": 37.7865239,
         "longitude": -122.4017847
      },
      {
         "timestampMs": 1340771407037,
         "latitude": 37.7865196,
         "longitude": -122.4017949
      },
      {
         "timestampMs": 1340767784003,
         "latitude": 37.7865196,
         "longitude": -122.4017949
      },
      {
         "timestampMs": 1340766709121,
         "latitude": 37.7863269,
         "longitude": -122.4021777
      },
      {
         "timestampMs": 1340766587766,
         "latitude": 37.7845088,
         "longitude": -122.40064
      },
      {
         "timestampMs": 1340766584350,
         "latitude": 37.7855348,
         "longitude": -122.4010481
      },
      {
         "timestampMs": 1340766523412,
         "latitude": 37.7847217,
         "longitude": -122.4020957
      },
      {
         "timestampMs": 1340766403390,
         "latitude": 37.785005,
         "longitude": -122.402977
      },
      {
         "timestampMs": 1340766226698,
         "latitude": 37.7851347,
         "longitude": -122.4050652
      },
      {
         "timestampMs": 1340766105690,
         "latitude": 37.7851872,
         "longitude": -122.4065738
      },
      {
         "timestampMs": 1340766044805,
         "latitude": 37.7848905,
         "longitude": -122.4070434
      },
      {
         "timestampMs": 1340765984184,
         "latitude": 37.7841144,
         "longitude": -122.4079132
      },
      {
         "timestampMs": 1340765924092,
         "latitude": 37.7840118,
         "longitude": -122.4085531
      },
      {
         "timestampMs": 1340765863848,
         "latitude": 37.7840118,
         "longitude": -122.4085531
      },
      {
         "timestampMs": 1340765566152,
         "latitude": 37.7933063,
         "longitude": -122.4077387
      },
      {
         "timestampMs": 1340765447714,
         "latitude": 37.7941146,
         "longitude": -122.4075629
      },
      {
         "timestampMs": 1340762420397,
         "latitude": 37.7945829,
         "longitude": -122.4063497
      },
      {
         "timestampMs": 1340762300381,
         "latitude": 37.7942072,
         "longitude": -122.406292
      },
      {
         "timestampMs": 1340762240880,
         "latitude": 37.7942025,
         "longitude": -122.4062745
      },
      {
         "timestampMs": 1340761899353,
         "latitude": 37.7936711,
         "longitude": -122.4060061
      },
      {
         "timestampMs": 1340761840098,
         "latitude": 37.794474,
         "longitude": -122.406234
      },
      {
         "timestampMs": 1340761640010,
         "latitude": 37.794474,
         "longitude": -122.406234
      },
      {
         "timestampMs": 1340761622395,
         "latitude": 37.7938619,
         "longitude": -122.4056261
      },
      {
         "timestampMs": 1340760982404,
         "latitude": 37.7930309,
         "longitude": -122.4060053
      },
      {
         "timestampMs": 1340760741227,
         "latitude": 37.7922687,
         "longitude": -122.4063526
      },
      {
         "timestampMs": 1340760679489,
         "latitude": 37.7917457,
         "longitude": -122.4057065
      },
      {
         "timestampMs": 1340760381736,
         "latitude": 37.7907936,
         "longitude": -122.405623
      },
      {
         "timestampMs": 1340760319391,
         "latitude": 37.7892545,
         "longitude": -122.4065918
      },
      {
         "timestampMs": 1340760201755,
         "latitude": 37.7904457,
         "longitude": -122.4063411
      },
      {
         "timestampMs": 1340760082403,
         "latitude": 37.7902438,
         "longitude": -122.407883
      },
      {
         "timestampMs": 1340759900527,
         "latitude": 37.7889621,
         "longitude": -122.4085732
      },
      {
         "timestampMs": 1340759842109,
         "latitude": 37.7877522,
         "longitude": -122.4079416
      },
      {
         "timestampMs": 1340759719123,
         "latitude": 37.7861619,
         "longitude": -122.4081789
      },
      {
         "timestampMs": 1340759538233,
         "latitude": 37.785346,
         "longitude": -122.408447
      },
      {
         "timestampMs": 1340759419268,
         "latitude": 37.785346,
         "longitude": -122.408447
      },
      {
         "timestampMs": 1340758938702,
         "latitude": 37.7839531,
         "longitude": -122.4076518
      },
      {
         "timestampMs": 1340758578500,
         "latitude": 37.7846275,
         "longitude": -122.4078354
      },
      {
         "timestampMs": 1340758459994,
         "latitude": 37.7841955,
         "longitude": -122.4080846
      },
      {
         "timestampMs": 1340758397545,
         "latitude": 37.7834318,
         "longitude": -122.4090625
      },
      {
         "timestampMs": 1340758220858,
         "latitude": 37.7825099,
         "longitude": -122.4102444
      },
      {
         "timestampMs": 1340758158439,
         "latitude": 37.7818321,
         "longitude": -122.411118
      },
      {
         "timestampMs": 1340758038409,
         "latitude": 37.7812545,
         "longitude": -122.4118643
      },
      {
         "timestampMs": 1340757618243,
         "latitude": 37.780925,
         "longitude": -122.412264
      },
      {
         "timestampMs": 1340757497302,
         "latitude": 37.7844375,
         "longitude": -122.4170248
      },
      {
         "timestampMs": 1340756357806,
         "latitude": 37.7807401,
         "longitude": -122.4121854
      },
      {
         "timestampMs": 1340755516345,
         "latitude": 37.7805315,
         "longitude": -122.4126436
      },
      {
         "timestampMs": 1340755337230,
         "latitude": 37.7798644,
         "longitude": -122.4134235
      },
      {
         "timestampMs": 1340755277261,
         "latitude": 37.7806908,
         "longitude": -122.4124229
      },
      {
         "timestampMs": 1340754088253,
         "latitude": 37.7814386,
         "longitude": -122.4124597
      },
      {
         "timestampMs": 1340752709875,
         "latitude": 37.7810585,
         "longitude": -122.4122235
      },
      {
         "timestampMs": 1340752647484,
         "latitude": 37.7806532,
         "longitude": -122.4127627
      },
      {
         "timestampMs": 1340752529999,
         "latitude": 37.7814271,
         "longitude": -122.4116724
      },
      {
         "timestampMs": 1340752527434,
         "latitude": 37.7824465,
         "longitude": -122.4103949
      },
      {
         "timestampMs": 1340752411863,
         "latitude": 37.7837708,
         "longitude": -122.4085273
      },
      {
         "timestampMs": 1340752287230,
         "latitude": 37.7839286,
         "longitude": -122.4075886
      },
      {
         "timestampMs": 1340751749837,
         "latitude": 37.7856262,
         "longitude": -122.4055196
      },
      {
         "timestampMs": 1340751687243,
         "latitude": 37.7850111,
         "longitude": -122.4048838
      },
      {
         "timestampMs": 1340751632136,
         "latitude": 37.7849199,
         "longitude": -122.404724
      },
      {
         "timestampMs": 1340751446068,
         "latitude": 37.7844672,
         "longitude": -122.40064
      },
      {
         "timestampMs": 1340751327020,
         "latitude": 37.7848137,
         "longitude": -122.4025905
      },
      {
         "timestampMs": 1340751209067,
         "latitude": 37.78432,
         "longitude": -122.40064
      },
      {
         "timestampMs": 1340751206080,
         "latitude": 37.7847667,
         "longitude": -122.4027982
      },
      {
         "timestampMs": 1340751146000,
         "latitude": 37.78448,
         "longitude": -122.4006528
      },
      {
         "timestampMs": 1340751026843,
         "latitude": 37.784448,
         "longitude": -122.4007424
      },
      {
         "timestampMs": 1340751012729,
         "latitude": 37.7849455,
         "longitude": -122.4025674
      },
      {
         "timestampMs": 1340750950117,
         "latitude": 37.7849585,
         "longitude": -122.4025573
      },
      {
         "timestampMs": 1340750943906,
         "latitude": 37.7841344,
         "longitude": -122.400448
      },
      {
         "timestampMs": 1340750686177,
         "latitude": 37.784765,
         "longitude": -122.4028618
      },
      {
         "timestampMs": 1340750327481,
         "latitude": 37.7846176,
         "longitude": -122.4029989
      },
      {
         "timestampMs": 1340750265107,
         "latitude": 37.7841451,
         "longitude": -122.4037659
      },
      {
         "timestampMs": 1340749305580,
         "latitude": 37.78373,
         "longitude": -122.4033636
      },
      {
         "timestampMs": 1340749126921,
         "latitude": 37.7837321,
         "longitude": -122.4032388
      },
      {
         "timestampMs": 1340749008005,
         "latitude": 37.7839146,
         "longitude": -122.4037975
      },
      {
         "timestampMs": 1340748935000,
         "latitude": 37.78399,
         "longitude": -122.401316
      },
      {
         "timestampMs": 1340748465275,
         "latitude": 37.784838,
         "longitude": -122.4028102
      },
      {
         "timestampMs": 1340748408452,
         "latitude": 37.7848876,
         "longitude": -122.4025665
      },
      {
         "timestampMs": 1340748345091,
         "latitude": 37.7855517,
         "longitude": -122.4010355
      },
      {
         "timestampMs": 1340748224995,
         "latitude": 37.786335,
         "longitude": -122.4020124
      },
      {
         "timestampMs": 1340748104983,
         "latitude": 37.7876703,
         "longitude": -122.4032602
      },
      {
         "timestampMs": 1340747866975,
         "latitude": 37.789673,
         "longitude": -122.4009708
      },
      {
         "timestampMs": 1340747805476,
         "latitude": 37.7916998,
         "longitude": -122.3985663
      },
      {
         "timestampMs": 1340747744840,
         "latitude": 37.7932084,
         "longitude": -122.3963533
      },
      {
         "timestampMs": 1340747684838,
         "latitude": 37.7944903,
         "longitude": -122.3953793
      },
      {
         "timestampMs": 1340747559646,
         "latitude": 37.793431,
         "longitude": -122.396392
      },
      {
         "timestampMs": 1340747445569,
         "latitude": 37.7931058,
         "longitude": -122.39632
      },
      {
         "timestampMs": 1340747144555,
         "latitude": 37.7923285,
         "longitude": -122.3936265
      },
      {
         "timestampMs": 1340747090458,
         "latitude": 37.7921041,
         "longitude": -122.3933891
      },
      {
         "timestampMs": 1340747025543,
         "latitude": 37.7915094,
         "longitude": -122.3925969
      },
      {
         "timestampMs": 1340746968035,
         "latitude": 37.7906755,
         "longitude": -122.3933206
      },
      {
         "timestampMs": 1340746545038,
         "latitude": 37.7909435,
         "longitude": -122.3921151
      },
      {
         "timestampMs": 1340746485072,
         "latitude": 37.7901249,
         "longitude": -122.3914989
      },
      {
         "timestampMs": 1340746313506,
         "latitude": 37.7894757,
         "longitude": -122.3904334
      },
      {
         "timestampMs": 1340746309772,
         "latitude": 37.7900224,
         "longitude": -122.389824
      },
      {
         "timestampMs": 1340746307078,
         "latitude": 37.7893667,
         "longitude": -122.3901245
      },
      {
         "timestampMs": 1340746299478,
         "latitude": 37.7890173,
         "longitude": -122.3898308
      },
      {
         "timestampMs": 1340746206919,
         "latitude": 37.7883461,
         "longitude": -122.3902321
      },
      {
         "timestampMs": 1340746159000,
         "latitude": 37.7888842,
         "longitude": -122.3888129
      },
      {
         "timestampMs": 1340743907709,
         "latitude": 37.8043436,
         "longitude": -122.4029073
      },
      {
         "timestampMs": 1340743789600,
         "latitude": 37.8075715,
         "longitude": -122.4081257
      },
      {
         "timestampMs": 1340743666132,
         "latitude": 37.8073999,
         "longitude": -122.4111041
      },
      {
         "timestampMs": 1340743125893,
         "latitude": 37.8091229,
         "longitude": -122.4110098
      },
      {
         "timestampMs": 1340743007161,
         "latitude": 37.8098458,
         "longitude": -122.4116406
      },
      {
         "timestampMs": 1340742885808,
         "latitude": 37.8093651,
         "longitude": -122.4111469
      },
      {
         "timestampMs": 1340742771307,
         "latitude": 37.8112894,
         "longitude": -122.4107395
      },
      {
         "timestampMs": 1340742345428,
         "latitude": 37.8103605,
         "longitude": -122.4106691
      },
      {
         "timestampMs": 1340742224439,
         "latitude": 37.809698,
         "longitude": -122.4103441
      },
      {
         "timestampMs": 1340742044431,
         "latitude": 37.8087103,
         "longitude": -122.4100249
      },
      {
         "timestampMs": 1340740217058,
         "latitude": 37.808549,
         "longitude": -122.4094598
      },
      {
         "timestampMs": 1340737633529,
         "latitude": 37.8085017,
         "longitude": -122.4100744
      },
      {
         "timestampMs": 1340737570697,
         "latitude": 37.8086879,
         "longitude": -122.4101178
      },
      {
         "timestampMs": 1340736613081,
         "latitude": 37.8096518,
         "longitude": -122.4104455
      },
      {
         "timestampMs": 1340736493141,
         "latitude": 37.8088216,
         "longitude": -122.410196
      },
      {
         "timestampMs": 1340736310192,
         "latitude": 37.8090193,
         "longitude": -122.4109777
      },
      {
         "timestampMs": 1340735889140,
         "latitude": 37.8088702,
         "longitude": -122.413876
      },
      {
         "timestampMs": 1340735831771,
         "latitude": 37.8076275,
         "longitude": -122.4172119
      },
      {
         "timestampMs": 1340735651329,
         "latitude": 37.8086717,
         "longitude": -122.4138946
      },
      {
         "timestampMs": 1340735530608,
         "latitude": 37.8046748,
         "longitude": -122.4492515
      },
      {
         "timestampMs": 1340735468944,
         "latitude": 37.8102499,
         "longitude": -122.4122634
      },
      {
         "timestampMs": 1340735352162,
         "latitude": 37.8322718,
         "longitude": -122.4815458
      },
      {
         "timestampMs": 1340735228782,
         "latitude": 37.8079926,
         "longitude": -122.4181161
      },
      {
         "timestampMs": 1340735050241,
         "latitude": 37.8077492,
         "longitude": -122.4190077
      },
      {
         "timestampMs": 1340734991144,
         "latitude": 37.8082372,
         "longitude": -122.4122503
      },
      {
         "timestampMs": 1340734929321,
         "latitude": 37.8060132,
         "longitude": -122.4130501
      },
      {
         "timestampMs": 1340734871055,
         "latitude": 37.8036836,
         "longitude": -122.4175078
      },
      {
         "timestampMs": 1340731827533,
         "latitude": 37.8090138,
         "longitude": -122.411035
      },
      {
         "timestampMs": 1340731587460,
         "latitude": 37.8089357,
         "longitude": -122.4138741
      },
      {
         "timestampMs": 1340731407288,
         "latitude": 37.8086913,
         "longitude": -122.4114275
      },
      {
         "timestampMs": 1340731226357,
         "latitude": 37.8088658,
         "longitude": -122.4132378
      },
      {
         "timestampMs": 1340731107939,
         "latitude": 37.8088696,
         "longitude": -122.4132194
      },
      {
         "timestampMs": 1340727505794,
         "latitude": 37.7848405,
         "longitude": -122.4074653
      },
      {
         "timestampMs": 1340727025789,
         "latitude": 37.7803599,
         "longitude": -122.4127088
      },
      {
         "timestampMs": 1340726725592,
         "latitude": 37.7814274,
         "longitude": -122.4123355
      },
      {
         "timestampMs": 1340726605540,
         "latitude": 37.780925,
         "longitude": -122.412264
      },
      {
         "timestampMs": 1340725656756,
         "latitude": 37.7818396,
         "longitude": -122.4113782
      },
      {
         "timestampMs": 1340725476620,
         "latitude": 37.781536,
         "longitude": -122.4124619
      },
      {
         "timestampMs": 1340725056598,
         "latitude": 37.7814089,
         "longitude": -122.4117168
      },
      {
         "timestampMs": 1340724936498,
         "latitude": 37.7819285,
         "longitude": -122.4111556
      },
      {
         "timestampMs": 1340723976365,
         "latitude": 37.7839387,
         "longitude": -122.4076655
      },
      {
         "timestampMs": 1340723738143,
         "latitude": 37.7841155,
         "longitude": -122.4079455
      },
      {
         "timestampMs": 1340723196078,
         "latitude": 37.7819037,
         "longitude": -122.4111843
      },
      {
         "timestampMs": 1340723015084,
         "latitude": 37.7812174,
         "longitude": -122.4120271
      },
      {
         "timestampMs": 1340722895938,
         "latitude": 37.780925,
         "longitude": -122.412264
      },
      {
         "timestampMs": 1340722835936,
         "latitude": 37.780925,
         "longitude": -122.412264
      },
      {
         "timestampMs": 1340722775937,
         "latitude": 37.780925,
         "longitude": -122.412264
      },
      {
         "timestampMs": 1340722114713,
         "latitude": 37.780925,
         "longitude": -122.412264
      },
      {
         "timestampMs": 1340721455259,
         "latitude": 37.7807728,
         "longitude": -122.4124684
      },
      {
         "timestampMs": 1340721155093,
         "latitude": 37.7814082,
         "longitude": -122.4124265
      },
      {
         "timestampMs": 1340717553141,
         "latitude": 37.780925,
         "longitude": -122.412264
      },
      {
         "timestampMs": 1340717373108,
         "latitude": 37.780925,
         "longitude": -122.412264
      },
      {
         "timestampMs": 1340717193033,
         "latitude": 37.781871,
         "longitude": -122.411918
      },
      {
         "timestampMs": 1340716731177,
         "latitude": 37.7814306,
         "longitude": -122.4124494
      },
      {
         "timestampMs": 1340715590709,
         "latitude": 37.780925,
         "longitude": -122.412264
      },
      {
         "timestampMs": 1340715410511,
         "latitude": 37.7815318,
         "longitude": -122.4117913
      },
      {
         "timestampMs": 1340714390090,
         "latitude": 37.7814386,
         "longitude": -122.4123703
      },
      {
         "timestampMs": 1340710368319,
         "latitude": 37.7814356,
         "longitude": -122.4124318
      },
      {
         "timestampMs": 1340708687860,
         "latitude": 37.780925,
         "longitude": -122.412264
      },
      {
         "timestampMs": 1340708447501,
         "latitude": 37.780925,
         "longitude": -122.412264
      },
      {
         "timestampMs": 1340704545104,
         "latitude": 37.780925,
         "longitude": -122.412264
      },
      {
         "timestampMs": 1340704245950,
         "latitude": 37.780925,
         "longitude": -122.412264
      },
      {
         "timestampMs": 1340700585060,
         "latitude": 37.780925,
         "longitude": -122.412264
      },
      {
         "timestampMs": 1340697314341,
         "latitude": 37.780925,
         "longitude": -122.412264
      },
      {
         "timestampMs": 1340693712333,
         "latitude": 37.7814268,
         "longitude": -122.4123664
      },
      {
         "timestampMs": 1340693532426,
         "latitude": 37.780925,
         "longitude": -122.412264
      },
      {
         "timestampMs": 1340692927156,
         "latitude": 37.7809364,
         "longitude": -122.4122042
      },
      {
         "timestampMs": 1340692806114,
         "latitude": 37.7804579,
         "longitude": -122.4126578
      },
      {
         "timestampMs": 1340692746106,
         "latitude": 37.7798644,
         "longitude": -122.4134235
      },
      {
         "timestampMs": 1340692447560,
         "latitude": 37.7806233,
         "longitude": -122.4124397
      },
      {
         "timestampMs": 1340688906071,
         "latitude": 37.7643502,
         "longitude": -122.4202649
      },
      {
         "timestampMs": 1340688785270,
         "latitude": 37.7181248,
         "longitude": -122.4509123
      },
      {
         "timestampMs": 1340688725923,
         "latitude": 37.7132754,
         "longitude": -122.4578904
      },
      {
         "timestampMs": 1340688587909,
         "latitude": 37.7207587,
         "longitude": -122.4496517
      },
      {
         "timestampMs": 1340688395649,
         "latitude": 37.7099915,
         "longitude": -122.4641426
      },
      {
         "timestampMs": 1340688343102,
         "latitude": 37.7054905,
         "longitude": -122.4688554
      },
      {
         "timestampMs": 1340687121936,
         "latitude": 37.6160503,
         "longitude": -122.3928378
      },
      {
         "timestampMs": 1340687002803,
         "latitude": 37.6169404,
         "longitude": -122.392207
      },
      {
         "timestampMs": 1340686885333,
         "latitude": 37.6158449,
         "longitude": -122.3943523
      },
      {
         "timestampMs": 1340686705251,
         "latitude": 37.6160197,
         "longitude": -122.3928716
      },
      {
         "timestampMs": 1340686341652,
         "latitude": 37.6175149,
         "longitude": -122.3872048
      },
      {
         "timestampMs": 1340686281618,
         "latitude": 37.6180262,
         "longitude": -122.3872439
      },
      {
         "timestampMs": 1340685381431,
         "latitude": 37.6175314,
         "longitude": -122.3866751
      },
      {
         "timestampMs": 1340684052000,
         "latitude": 37.615201,
         "longitude": -122.3906
      },
      {
         "timestampMs": 1340683701549,
         "latitude": 37.6185527,
         "longitude": -122.3871441
      },
      {
         "timestampMs": 1340683691405,
         "latitude": 37.6185305,
         "longitude": -122.3871043
      },
      {
         "timestampMs": 1340683403165,
         "latitude": 37.6175249,
         "longitude": -122.3867372
      },
      {
         "timestampMs": 1340683341576,
         "latitude": 37.6182681,
         "longitude": -122.387203
      },
      {
         "timestampMs": 1340683165634,
         "latitude": 37.6199499,
         "longitude": -122.3873897
      },
      {
         "timestampMs": 1340683104565,
         "latitude": 37.6191783,
         "longitude": -122.3876044
      },
      {
         "timestampMs": 1340682922006,
         "latitude": 37.6185091,
         "longitude": -122.3880413
      },
      {
         "timestampMs": 1340682862062,
         "latitude": 37.620703,
         "longitude": -122.3873397
      },
      {
         "timestampMs": 1340662101641,
         "latitude": 40.6955121,
         "longitude": -74.1830461
      },
      {
         "timestampMs": 1340661982460,
         "latitude": 40.7097026,
         "longitude": -74.1900765
      },
      {
         "timestampMs": 1340656409445,
         "latitude": 40.6955695,
         "longitude": -74.173305
      },
      {
         "timestampMs": 1340654247868,
         "latitude": 40.695469,
         "longitude": -74.1734033
      },
      {
         "timestampMs": 1340653168584,
         "latitude": 40.6945649,
         "longitude": -74.1735802
      },
      {
         "timestampMs": 1340652268357,
         "latitude": 40.6945649,
         "longitude": -74.1735802
      },
      {
         "timestampMs": 1340651455215,
         "latitude": 40.6948272,
         "longitude": -74.173604
      },
      {
         "timestampMs": 1340651395054,
         "latitude": 40.6947142,
         "longitude": -74.1735713
      },
      {
         "timestampMs": 1340651154846,
         "latitude": 40.6942128,
         "longitude": -74.1729953
      },
      {
         "timestampMs": 1340650914791,
         "latitude": 40.6947872,
         "longitude": -74.1735546
      },
      {
         "timestampMs": 1340650673826,
         "latitude": 40.6946147,
         "longitude": -74.1735382
      },
      {
         "timestampMs": 1340650254609,
         "latitude": 40.6942128,
         "longitude": -74.1729953
      },
      {
         "timestampMs": 1340649836741,
         "latitude": 40.6949218,
         "longitude": -74.1738486
      },
      {
         "timestampMs": 1340649780474,
         "latitude": 40.694839,
         "longitude": -74.1738571
      },
      {
         "timestampMs": 1340649413352,
         "latitude": 40.6942128,
         "longitude": -74.1729953
      },
      {
         "timestampMs": 1340646541977,
         "latitude": 40.6932694,
         "longitude": -74.173746
      },
      {
         "timestampMs": 1340646411778,
         "latitude": 40.6944215,
         "longitude": -74.1752101
      },
      {
         "timestampMs": 1340642773612,
         "latitude": 40.6942128,
         "longitude": -74.1729953
      },
      {
         "timestampMs": 1340636831334,
         "latitude": 40.751045,
         "longitude": -73.994419
      },
      {
         "timestampMs": 1340634857128,
         "latitude": 40.7501715,
         "longitude": -73.9906058
      },
      {
         "timestampMs": 1340633956773,
         "latitude": 40.7479828,
         "longitude": -73.9930158
      },
      {
         "timestampMs": 1340632756153,
         "latitude": 40.7476695,
         "longitude": -73.9945316
      },
      {
         "timestampMs": 1340630595418,
         "latitude": 40.7481567,
         "longitude": -73.994671
      },
      {
         "timestampMs": 1340628494388,
         "latitude": 40.7477034,
         "longitude": -73.9944637
      },
      {
         "timestampMs": 1340627233713,
         "latitude": 40.74849,
         "longitude": -73.994593
      },
      {
         "timestampMs": 1340626993686,
         "latitude": 40.7480608,
         "longitude": -73.9929378
      },
      {
         "timestampMs": 1340626213402,
         "latitude": 40.750171,
         "longitude": -73.9907179
      },
      {
         "timestampMs": 1340604364085,
         "latitude": 40.7501959,
         "longitude": -73.9907977
      },
      {
         "timestampMs": 1340600403614,
         "latitude": 40.750196,
         "longitude": -73.9908834
      },
      {
         "timestampMs": 1340596284364,
         "latitude": 40.7501577,
         "longitude": -73.9909644
      },
      {
         "timestampMs": 1340595083200,
         "latitude": 40.748693,
         "longitude": -73.988274
      },
      {
         "timestampMs": 1340591482072,
         "latitude": 40.7484278,
         "longitude": -73.9926998
      },
      {
         "timestampMs": 1340591422003,
         "latitude": 40.7480383,
         "longitude": -73.9930062
      },
      {
         "timestampMs": 1340590760887,
         "latitude": 40.74849,
         "longitude": -73.994593
      },
      {
         "timestampMs": 1340586590743,
         "latitude": 40.74849,
         "longitude": -73.994593
      },
      {
         "timestampMs": 1340585990584,
         "latitude": 40.74849,
         "longitude": -73.994593
      },
      {
         "timestampMs": 1340584970376,
         "latitude": 40.7480089,
         "longitude": -73.9929794
      },
      {
         "timestampMs": 1340584790280,
         "latitude": 40.7477702,
         "longitude": -73.9952593
      },
      {
         "timestampMs": 1340584670290,
         "latitude": 40.7479786,
         "longitude": -73.9930075
      },
      {
         "timestampMs": 1340584550075,
         "latitude": 40.7477702,
         "longitude": -73.9952596
      },
      {
         "timestampMs": 1340584249771,
         "latitude": 40.74849,
         "longitude": -73.994593
      },
      {
         "timestampMs": 1340583649665,
         "latitude": 40.7480081,
         "longitude": -73.9929833
      },
      {
         "timestampMs": 1340580826881,
         "latitude": 40.7478612,
         "longitude": -73.994957
      },
      {
         "timestampMs": 1340580047279,
         "latitude": 40.74849,
         "longitude": -73.994593
      },
      {
         "timestampMs": 1340579827974,
         "latitude": 40.7479418,
         "longitude": -73.9949981
      },
      {
         "timestampMs": 1340578632991,
         "latitude": 40.747681,
         "longitude": -73.9945056
      },
      {
         "timestampMs": 1340578512945,
         "latitude": 40.7480673,
         "longitude": -73.9929462
      },
      {
         "timestampMs": 1340576592779,
         "latitude": 40.751258,
         "longitude": -73.990528
      },
      {
         "timestampMs": 1340576473143,
         "latitude": 40.751258,
         "longitude": -73.990528
      },
      {
         "timestampMs": 1340572871642,
         "latitude": 40.7484958,
         "longitude": -73.9926313
      },
      {
         "timestampMs": 1340571490003,
         "latitude": 40.7478734,
         "longitude": -73.9947209
      },
      {
         "timestampMs": 1340571309942,
         "latitude": 40.74849,
         "longitude": -73.994593
      },
      {
         "timestampMs": 1340570591272,
         "latitude": 40.7464579,
         "longitude": -73.9936958
      },
      {
         "timestampMs": 1340566224396,
         "latitude": 40.747431,
         "longitude": -73.99315
      },
      {
         "timestampMs": 1340562622223,
         "latitude": 40.7476581,
         "longitude": -73.9945466
      },
      {
         "timestampMs": 1340562202107,
         "latitude": 40.74849,
         "longitude": -73.994593
      },
      {
         "timestampMs": 1340559185509,
         "latitude": 40.74849,
         "longitude": -73.994593
      },
      {
         "timestampMs": 1340558944717,
         "latitude": 40.7480543,
         "longitude": -73.9929396
      },
      {
         "timestampMs": 1340558716392,
         "latitude": 40.7450586,
         "longitude": -73.9948409
      },
      {
         "timestampMs": 1340558645917,
         "latitude": 40.7445335,
         "longitude": -73.9955868
      },
      {
         "timestampMs": 1340558585332,
         "latitude": 40.7448673,
         "longitude": -73.9960179
      },
      {
         "timestampMs": 1340557683218,
         "latitude": 40.7473841,
         "longitude": -73.9928132
      },
      {
         "timestampMs": 1340557623197,
         "latitude": 40.7471437,
         "longitude": -73.994811
      },
      {
         "timestampMs": 1340557567365,
         "latitude": 40.7472505,
         "longitude": -73.9936244
      },
      {
         "timestampMs": 1340555293082,
         "latitude": 40.7476896,
         "longitude": -73.9945399
      },
      {
         "timestampMs": 1340555078787,
         "latitude": 40.747207,
         "longitude": -73.9949364
      },
      {
         "timestampMs": 1340554801155,
         "latitude": 40.7473628,
         "longitude": -73.9953731
      },
      {
         "timestampMs": 1340554441952,
         "latitude": 40.7478095,
         "longitude": -73.9962499
      },
      {
         "timestampMs": 1340554321939,
         "latitude": 40.7473037,
         "longitude": -73.9949617
      },
      {
         "timestampMs": 1340552581028,
         "latitude": 40.7477022,
         "longitude": -73.9945611
      },
      {
         "timestampMs": 1340552460965,
         "latitude": 40.74849,
         "longitude": -73.994593
      },
      {
         "timestampMs": 1340552280919,
         "latitude": 40.74849,
         "longitude": -73.994593
      },
      {
         "timestampMs": 1340550659911,
         "latitude": 40.7464356,
         "longitude": -73.9938817
      },
      {
         "timestampMs": 1340546113503,
         "latitude": 40.7469574,
         "longitude": -73.9937165
      },
      {
         "timestampMs": 1340544492553,
         "latitude": 40.7478727,
         "longitude": -73.9947203
      },
      {
         "timestampMs": 1340542810501,
         "latitude": 40.74849,
         "longitude": -73.994593
      },
      {
         "timestampMs": 1340541311083,
         "latitude": 40.7471696,
         "longitude": -73.9950066
      },
      {
         "timestampMs": 1340541189866,
         "latitude": 40.7474254,
         "longitude": -73.9959059
      },
      {
         "timestampMs": 1340541112140,
         "latitude": 40.7472432,
         "longitude": -73.9950308
      },
      {
         "timestampMs": 1340540109428,
         "latitude": 40.74849,
         "longitude": -73.994593
      },
      {
         "timestampMs": 1340539629778,
         "latitude": 40.74849,
         "longitude": -73.994593
      },
      {
         "timestampMs": 1340539275846,
         "latitude": 40.7492474,
         "longitude": -73.9919632
      },
      {
         "timestampMs": 1340535674714,
         "latitude": 40.7501867,
         "longitude": -73.9906375
      },
      {
         "timestampMs": 1340535613773,
         "latitude": 40.7501867,
         "longitude": -73.9906375
      },
      {
         "timestampMs": 1340535434655,
         "latitude": 40.7501867,
         "longitude": -73.9906375
      },
      {
         "timestampMs": 1340535314619,
         "latitude": 40.7501867,
         "longitude": -73.9906375
      },
      {
         "timestampMs": 1340531712980,
         "latitude": 40.7501867,
         "longitude": -73.9906375
      },
      {
         "timestampMs": 1340531172839,
         "latitude": 40.750179,
         "longitude": -73.9906524
      },
      {
         "timestampMs": 1340531112847,
         "latitude": 40.750179,
         "longitude": -73.9906524
      },
      {
         "timestampMs": 1340531052816,
         "latitude": 40.750179,
         "longitude": -73.9906524
      },
      {
         "timestampMs": 1340527451601,
         "latitude": 40.750179,
         "longitude": -73.9906524
      },
      {
         "timestampMs": 1340525050852,
         "latitude": 40.750211,
         "longitude": -73.9906668
      },
      {
         "timestampMs": 1340524930738,
         "latitude": 40.750211,
         "longitude": -73.9906668
      },
      {
         "timestampMs": 1340521309033,
         "latitude": 40.750211,
         "longitude": -73.9906668
      },
      {
         "timestampMs": 1340509203845,
         "latitude": 40.7477891,
         "longitude": -73.9946762
      },
      {
         "timestampMs": 1340505062930,
         "latitude": 40.74849,
         "longitude": -73.994593
      },
      {
         "timestampMs": 1340504821926,
         "latitude": 40.7476778,
         "longitude": -73.9945525
      },
      {
         "timestampMs": 1340501220633,
         "latitude": 40.74849,
         "longitude": -73.994593
      },
      {
         "timestampMs": 1340498339207,
         "latitude": 40.74849,
         "longitude": -73.994593
      },
      {
         "timestampMs": 1340496544331,
         "latitude": 40.7476764,
         "longitude": -73.9944715
      },
      {
         "timestampMs": 1340496484321,
         "latitude": 40.7476796,
         "longitude": -73.9944784
      },
      {
         "timestampMs": 1340495396788,
         "latitude": 40.7473608,
         "longitude": -73.9952681
      },
      {
         "timestampMs": 1340495036351,
         "latitude": 40.74849,
         "longitude": -73.994593
      },
      {
         "timestampMs": 1340494796268,
         "latitude": 40.74849,
         "longitude": -73.994593
      },
      {
         "timestampMs": 1340491193814,
         "latitude": 40.7477156,
         "longitude": -73.9945974
      },
      {
         "timestampMs": 1340490416169,
         "latitude": 40.74849,
         "longitude": -73.994593
      },
      {
         "timestampMs": 1340486313826,
         "latitude": 40.7473736,
         "longitude": -73.9958302
      },
      {
         "timestampMs": 1340486193745,
         "latitude": 40.7478063,
         "longitude": -73.9945598
      },
      {
         "timestampMs": 1340485593619,
         "latitude": 40.7478063,
         "longitude": -73.9945598
      },
      {
         "timestampMs": 1340485173099,
         "latitude": 40.7478063,
         "longitude": -73.9945598
      },
      {
         "timestampMs": 1340485113076,
         "latitude": 40.7478063,
         "longitude": -73.9945598
      },
      {
         "timestampMs": 1340481454053,
         "latitude": 40.7478063,
         "longitude": -73.9945598
      },
      {
         "timestampMs": 1340472502193,
         "latitude": 40.7472529,
         "longitude": -73.9951032
      },
      {
         "timestampMs": 1340467432639,
         "latitude": 40.7474662,
         "longitude": -73.9960111
      },
      {
         "timestampMs": 1340467311585,
         "latitude": 40.7472416,
         "longitude": -73.995034
      },
      {
         "timestampMs": 1340467251580,
         "latitude": 40.7474111,
         "longitude": -73.9959654
      },
      {
         "timestampMs": 1340459809659,
         "latitude": 40.7474344,
         "longitude": -73.9960445
      },
      {
         "timestampMs": 1340455067910,
         "latitude": 40.7473745,
         "longitude": -73.9958098
      },
      {
         "timestampMs": 1340452726906,
         "latitude": 40.7499759,
         "longitude": -73.9914182
      },
      {
         "timestampMs": 1340452126803,
         "latitude": 40.7501744,
         "longitude": -73.9907923
      },
      {
         "timestampMs": 1340451826694,
         "latitude": 40.7501328,
         "longitude": -73.9913079
      },
      {
         "timestampMs": 1340448135750,
         "latitude": 40.7501704,
         "longitude": -73.9908805
      },
      {
         "timestampMs": 1340444474385,
         "latitude": 40.7501982,
         "longitude": -73.9908894
      },
      {
         "timestampMs": 1340429889034,
         "latitude": 40.7501725,
         "longitude": -73.9908495
      },
      {
         "timestampMs": 1340426288066,
         "latitude": 40.7501725,
         "longitude": -73.9908495
      },
      {
         "timestampMs": 1340422024912,
         "latitude": 40.7475565,
         "longitude": -73.9959389
      },
      {
         "timestampMs": 1340421785090,
         "latitude": 40.74849,
         "longitude": -73.994593
      },
      {
         "timestampMs": 1340418602796,
         "latitude": 40.7455,
         "longitude": -73.991047
      },
      {
         "timestampMs": 1340415000444,
         "latitude": 40.748363,
         "longitude": -73.9949112
      },
      {
         "timestampMs": 1340413799500,
         "latitude": 40.747326,
         "longitude": -73.995327
      },
      {
         "timestampMs": 1340405858691,
         "latitude": 40.747326,
         "longitude": -73.995327
      },
      {
         "timestampMs": 1340404117814,
         "latitude": 40.7472,
         "longitude": -73.9949692
      },
      {
         "timestampMs": 1340403584266,
         "latitude": 40.7473709,
         "longitude": -73.9954339
      },
      {
         "timestampMs": 1340403217543,
         "latitude": 40.7472777,
         "longitude": -73.994991
      },
      {
         "timestampMs": 1340403097597,
         "latitude": 40.7474982,
         "longitude": -73.99598
      },
      {
         "timestampMs": 1340402676664,
         "latitude": 40.750139,
         "longitude": -73.9910442
      },
      {
         "timestampMs": 1340402497344,
         "latitude": 40.7505856,
         "longitude": -73.9893248
      },
      {
         "timestampMs": 1340401116923,
         "latitude": 40.750171,
         "longitude": -73.9907733
      },
      {
         "timestampMs": 1340395954141,
         "latitude": 40.750437,
         "longitude": -73.991412
      },
      {
         "timestampMs": 1340387490946,
         "latitude": 40.7216973,
         "longitude": -73.9995339
      },
      {
         "timestampMs": 1340387315055,
         "latitude": 40.7218895,
         "longitude": -73.9996292
      },
      {
         "timestampMs": 1340378925271,
         "latitude": 40.7473636,
         "longitude": -73.9958398
      },
      {
         "timestampMs": 1340378685056,
         "latitude": 40.7474224,
         "longitude": -73.9957708
      },
      {
         "timestampMs": 1340369619564,
         "latitude": 40.7981812,
         "longitude": -73.9526851
      },
      {
         "timestampMs": 1340369260370,
         "latitude": 40.7984885,
         "longitude": -73.9537419
      },
      {
         "timestampMs": 1340367458538,
         "latitude": 40.7500492,
         "longitude": -73.9914773
      },
      {
         "timestampMs": 1340366408784,
         "latitude": 40.7501571,
         "longitude": -73.9908034
      },
      {
         "timestampMs": 1340332419016,
         "latitude": 40.7501321,
         "longitude": -73.9913076
      },
      {
         "timestampMs": 1340331938903,
         "latitude": 40.7501344,
         "longitude": -73.9906588
      },
      {
         "timestampMs": 1340331638813,
         "latitude": 40.751258,
         "longitude": -73.990528
      },
      {
         "timestampMs": 1340328010688,
         "latitude": 40.7502216,
         "longitude": -73.9908552
      },
      {
         "timestampMs": 1340327890624,
         "latitude": 40.7505856,
         "longitude": -73.9893248
      },
      {
         "timestampMs": 1340327710562,
         "latitude": 40.7500653,
         "longitude": -73.9908394
      },
      {
         "timestampMs": 1340324109348,
         "latitude": 40.7503158,
         "longitude": -73.991324
      },
      {
         "timestampMs": 1340320145271,
         "latitude": 40.7505856,
         "longitude": -73.9893248
      },
      {
         "timestampMs": 1340320085312,
         "latitude": 40.7501631,
         "longitude": -73.990762
      },
      {
         "timestampMs": 1340319965469,
         "latitude": 40.7505856,
         "longitude": -73.9893248
      },
      {
         "timestampMs": 1340318044274,
         "latitude": 40.750437,
         "longitude": -73.991412
      },
      {
         "timestampMs": 1340317446075,
         "latitude": 40.7503068,
         "longitude": -73.9913226
      },
      {
         "timestampMs": 1340316722712,
         "latitude": 40.7509555,
         "longitude": -73.9915451
      },
      {
         "timestampMs": 1340316667826,
         "latitude": 40.7508193,
         "longitude": -73.9918284
      },
      {
         "timestampMs": 1340313242458,
         "latitude": 40.8201042,
         "longitude": -73.9013324
      },
      {
         "timestampMs": 1340313122888,
         "latitude": 40.8248052,
         "longitude": -73.893055
      },
      {
         "timestampMs": 1340313062825,
         "latitude": 40.8275518,
         "longitude": -73.8913161
      },
      {
         "timestampMs": 1340311982176,
         "latitude": 40.8309682,
         "longitude": -73.8857051
      },
      {
         "timestampMs": 1340311562122,
         "latitude": 40.8456265,
         "longitude": -73.877099
      },
      {
         "timestampMs": 1340311381976,
         "latitude": 40.8514811,
         "longitude": -73.8726854
      },
      {
         "timestampMs": 1340311141931,
         "latitude": 40.845996,
         "longitude": -73.870526
      },
      {
         "timestampMs": 1340310961900,
         "latitude": 40.8525176,
         "longitude": -73.8724639
      },
      {
         "timestampMs": 1340310421479,
         "latitude": 40.8428467,
         "longitude": -73.8747156
      },
      {
         "timestampMs": 1340310180485,
         "latitude": 40.833762,
         "longitude": -73.882977
      },
      {
         "timestampMs": 1340310063002,
         "latitude": 40.838065,
         "longitude": -73.881268
      },
      {
         "timestampMs": 1340309766354,
         "latitude": 40.8456265,
         "longitude": -73.877099
      },
      {
         "timestampMs": 1340308385905,
         "latitude": 40.8514811,
         "longitude": -73.8726854
      },
      {
         "timestampMs": 1340296741082,
         "latitude": 40.8530559,
         "longitude": -73.8722424
      },
      {
         "timestampMs": 1340292125057,
         "latitude": 40.8514811,
         "longitude": -73.8726854
      },
      {
         "timestampMs": 1340291284746,
         "latitude": 40.8468378,
         "longitude": -73.877301
      },
      {
         "timestampMs": 1340291163638,
         "latitude": 40.8514811,
         "longitude": -73.8726854
      },
      {
         "timestampMs": 1340290923477,
         "latitude": 40.8455876,
         "longitude": -73.8770076
      },
      {
         "timestampMs": 1340290841000,
         "latitude": 40.849974,
         "longitude": -73.880772
      },
      {
         "timestampMs": 1340290746270,
         "latitude": 40.8455875,
         "longitude": -73.8770109
      },
      {
         "timestampMs": 1340290687087,
         "latitude": 40.8355574,
         "longitude": -73.8833501
      },
      {
         "timestampMs": 1340290091862,
         "latitude": 40.8480992,
         "longitude": -73.8716691
      },
      {
         "timestampMs": 1340289486256,
         "latitude": 40.8428331,
         "longitude": -73.8747362
      },
      {
         "timestampMs": 1340289425978,
         "latitude": 40.8401467,
         "longitude": -73.880995
      },
      {
         "timestampMs": 1340284882618,
         "latitude": 40.8210243,
         "longitude": -73.8997284
      },
      {
         "timestampMs": 1340284852188,
         "latitude": 40.8201437,
         "longitude": -73.9012423
      },
      {
         "timestampMs": 1340284758803,
         "latitude": 40.8162498,
         "longitude": -73.9095128
      },
      {
         "timestampMs": 1340280737866,
         "latitude": 40.7501561,
         "longitude": -73.9908818
      },
      {
         "timestampMs": 1340277016638,
         "latitude": 40.7502013,
         "longitude": -73.9908073
      },
      {
         "timestampMs": 1340275021302,
         "latitude": 40.7502013,
         "longitude": -73.9908073
      },
      {
         "timestampMs": 1340267519133,
         "latitude": 40.7501822,
         "longitude": -73.9907433
      },
      {
         "timestampMs": 1340263918126,
         "latitude": 40.7501822,
         "longitude": -73.9907433
      },
      {
         "timestampMs": 1340260076941,
         "latitude": 40.7501748,
         "longitude": -73.9907591
      },
      {
         "timestampMs": 1340252694709,
         "latitude": 40.7501835,
         "longitude": -73.9908197
      },
      {
         "timestampMs": 1340252454685,
         "latitude": 40.7501775,
         "longitude": -73.990705
      },
      {
         "timestampMs": 1340247982745,
         "latitude": 40.7501775,
         "longitude": -73.990705
      },
      {
         "timestampMs": 1340243780574,
         "latitude": 40.7504239,
         "longitude": -73.9911706
      },
      {
         "timestampMs": 1340243719785,
         "latitude": 40.7501699,
         "longitude": -73.9907106
      },
      {
         "timestampMs": 1340243660498,
         "latitude": 40.7501699,
         "longitude": -73.9907106
      },
      {
         "timestampMs": 1340240013270,
         "latitude": 40.7501699,
         "longitude": -73.9907106
      },
      {
         "timestampMs": 1340239741972,
         "latitude": 40.7510208,
         "longitude": -73.9903743
      },
      {
         "timestampMs": 1340239711952,
         "latitude": 40.750214,
         "longitude": -73.990768
      },
      {
         "timestampMs": 1340239706855,
         "latitude": 40.7512836,
         "longitude": -73.9886777
      },
      {
         "timestampMs": 1340239378134,
         "latitude": 40.7501734,
         "longitude": -73.9907422
      },
      {
         "timestampMs": 1340235387451,
         "latitude": 40.7501653,
         "longitude": -73.990743
      },
      {
         "timestampMs": 1340233885698,
         "latitude": 40.7536995,
         "longitude": -73.9926257
      },
      {
         "timestampMs": 1340233705602,
         "latitude": 40.7540375,
         "longitude": -73.9920202
      },
      {
         "timestampMs": 1340233285221,
         "latitude": 40.7534845,
         "longitude": -73.9926191
      },
      {
         "timestampMs": 1340233165231,
         "latitude": 40.7542257,
         "longitude": -73.9919745
      },
      {
         "timestampMs": 1340231843959,
         "latitude": 40.7541437,
         "longitude": -73.9919402
      },
      {
         "timestampMs": 1340231445000,
         "latitude": 40.753839,
         "longitude": -73.99204
      },
      {
         "timestampMs": 1340231284080,
         "latitude": 40.7538616,
         "longitude": -73.9922158
      },
      {
         "timestampMs": 1340231225457,
         "latitude": 40.7538624,
         "longitude": -73.9922389
      },
      {
         "timestampMs": 1340221323786,
         "latitude": 40.6999421,
         "longitude": -73.8073876
      },
      {
         "timestampMs": 1340221200463,
         "latitude": 40.6954544,
         "longitude": -73.8078821
      },
      {
         "timestampMs": 1340221020354,
         "latitude": 40.699489,
         "longitude": -73.809383
      },
      {
         "timestampMs": 1340220899470,
         "latitude": 40.688206,
         "longitude": -73.808791
      },
      {
         "timestampMs": 1340220781438,
         "latitude": 40.6752902,
         "longitude": -73.8022266
      },
      {
         "timestampMs": 1340220660676,
         "latitude": 40.6598795,
         "longitude": -73.8034682
      },
      {
         "timestampMs": 1340220421816,
         "latitude": 40.647003,
         "longitude": -73.790127
      },
      {
         "timestampMs": 1340220312000,
         "latitude": 40.643612,
         "longitude": -73.782201
      },
      {
         "timestampMs": 1340220299263,
         "latitude": 40.6440439,
         "longitude": -73.7907941
      },
      {
         "timestampMs": 1340220239800,
         "latitude": 40.6440439,
         "longitude": -73.7907941
      },
      {
         "timestampMs": 1340220217538,
         "latitude": 40.6431873,
         "longitude": -73.7891043
      }
    ]
  }
};