#!/usr/bin/perl -w

# Program sqlite_parse.pl

# (c) Gary C. Kessler, 2012 [gck@garykessler.net]

# Parser for SQLite database record files

# The program accepts two files: schema and data

# The schema file is a comma-delimited file containing the labels for the each
# of the defined fields. (File must end with a comma.) The schema file is optional.

# The data file has the following general format:

# Byte 0: Length of record (Counts only HEADER and DATA portion)
# Bytes 1-X: Key (May be Huffman coded)

# HEADER INFORMATION
# Bytes X+1 et seq.: Number of header bytes (N)
# Next N fields: Data field header values (may be Huffman coded)

# DATA INFORMATION
# Remaining bytes: Data bytes, organized per header information

# ********************************************************
# MAIN PROGRAM BLOCK
# ********************************************************

#use Encode qw/encode_utf8 decode_utf8/;
use utf8;
binmode STDOUT, ":utf8";

# Initialize global variables

$version = "2.3";
$build_date = "14 March 2013";

$source = "";
$schema = "";

print "\nSQLite Parser V$version - Gary C. Kessler ($build_date)\n\n";

# Parse command line switches.
# If user has supplied the -h, -v, or an illegal switch, the subroutine
# returns a value of 1 and the program stops.

if (parsecommandline ())
  { exit 1; };

if ($schema eq "!")
  { $schema = "NULL"; }

print "Source = $source  Schema File = $schema\n\n";

# Read schema file (single line) if there is one

if ($schema ne "NULL")
  {
  open (INFILE, "<", $schema)
    or die "Can't open input file \"$schema\": $!";

  $line = <INFILE>;
  $line =~ s/(\x0a|\x0d)//g;  # Get rid of CR and LF at end of line

  close INFILE;

#  Parse line into component fields

  @field_label = ();
  push(@field_label, $+)
  while $line =~ m{"([^\"\\]*(?:\\.[^\"\\]*)*)",? | ([^,]+),? | , }gx;
  push(@field_label, undef)
  if substr($line, -1,1) eq ',';

# Number of fields in schema is number_of_commas + 1

  $num_fields = ($line =~ s/,//g) + 1;

  print "SCHEMA FILE -- Field labels:\n\n";
  for ($i=0; $i<$num_fields; $i++)
    {
    printf ("%-20s", $field_label [$i]);
    if ($i%4 == 3)
      { print "\n"; }
    }

  if ($num_fields%4 != 0)
    { print "\n"; }
  }

# Open the database file.

open (INFILE, "<:raw", $source)
  or die "Can't open input file \"$source\": $!";
binmode INFILE;

$record_num = 0;

# Since there may be more than a single record, read the file until there's an EOF.
# Start by reading the first byte (Record Length).

do
  {

# Record Length (field 1) information is Byte 0

  read (INFILE,$byte,1);
  $record [0] = unpack ("C", $byte);
  $record_len = 1;
  $record_num++;

# Record Key (field 2) information. This value may be Huffmanm coded.

  $RK_len = 0;
  do
    {
    read (INFILE,$byte,1);
    $record [$record_len] = unpack ("C", $byte);
    $record_len++;
    $RK_len++;
    }
    until ($record [$record_len-1] < 0x80);

  $RecordKey = huffman_calc (1, $RK_len, @record);

# Now read the rest of this record

  for ($i = 0; $i < $record [0]; $i++)
    {
    read (INFILE,$byte,1);
    $record [$record_len] = unpack ("C", $byte);
    $record_len++;
    }

  print "\nDATA FILE -- Database record #$record_num length = $record_len bytes.\n\n";

# Display the raw record, 16 bytes per line

  $lines = int ($record_len/16);
  for ($i = 0; $i < $lines; $i++)
    { set_output ($i*16,16,@record); }

  if ($record_len%16 != 0)
    { set_output ($lines*16,($record_len-$lines*16),@record); }

  print "\n";

# Display Record Length and Record Key information

  printf ("000      Record length (Header & Data fields): ");
  list_hex_digits (0, 1, @record);
  print " [", $record [0], " bytes]\n";
  print "         (Entire record is ",$record[0]+1+$RK_len," bytes in length)\n\n";

  if ($RK_len == 1)
      { printf ("001      Record key: "); }
    else
      { printf ("001-%03d  Record key: ", $RK_len); }
  list_hex_digits (1, $RK_len, @record);
  print " [", $RecordKey, "]\n\n";

# Now, start the parsing!!!

  $len = $RK_len + 1;

# Process Header portion. First byte is Header length; remaining bytes describe the fields

  print "***** HEADER FIELDS *****\n\n";

  $bpos = $len;
  $len = 1;
  printf ("%03d      Header length: ", $bpos);
  list_hex_digits ($bpos, $len, @record);
  $header_len = $record[$bpos];
  print " [", $header_len, " bytes]\n\n";

# Now process $header_len-1 header value bytes
# $hcount counts the number of actual data values there are, because some
#    fields may require two header values for the full field count

  $hcount = 0;

  for ($i = 0; $i < $header_len-1; $i++)
    {
    $bpos += $len;

    ($len,$field_hdrval [$hcount]) = &huffman_check ($bpos, @record);
    if ($len > 1)
      { $i += $len - 1; }
    ($field_datatype [$hcount], $field_datasize [$hcount]) = &header_type ($field_hdrval [$hcount]);

    if ($len == 1)
        { printf ("%03d      Header %d", $bpos, $hcount+1); }
      else
        { printf ("%03d-%03d  Header %d", $bpos, $bpos+$len-1, $hcount+1); }

# If no SCHEMA file, use a field label of the length & type; if SCHEMA file exists, we already have the label

    if ($schema eq "NULL") { $field_label [$hcount] = $field_datasize [$hcount] . "-byte " . $field_datatype [$hcount]; }

    printf (" (%s): ", $field_label [$hcount]);
    list_hex_digits ($bpos, $len, @record);
    printf (" [%d]\n", $field_hdrval [$hcount]);

    print "         Data type = ", $field_datatype [$hcount], "  Data size = ", $field_datasize [$hcount]," byte(s)\n\n";
    $hcount++;
    }

# Now process Data fields.

  print "***** DATA FIELDS *****\n";

# Cycle through $hcount data fields and act based upon the data type

  for ($i = 0; $i < $hcount; $i++)
    {
    printf ("\nData %d (%s): ", $i+1, $field_label [$i]);
    $bpos += $len;
    $len = $field_datasize [$i];

# Look at value length. Ignore len = 0 (we get that later)

    CASE_LEN:
      {
      $len == 1 && do
        {
        printf ("\n%03d      ", $bpos);
        list_hex_digits ($bpos, 1, @record);
        };
      $len >= 2 && do
        { 
        $x = $bpos; $y = $len;
        while ($y > 16)
          {
          printf ("\n%03d-%03d  ", $x,$x+15); 
          list_hex_digits ($x, 16, @record);
          $x += 16; $y -= 16;
          }
        if ($y == 1)
            { printf ("\n%03d      ", $x); }
          else
            { printf ("\n%03d-%03d  ", $x,$x+$y-1); }
        list_hex_digits ($x, $y, @record);
        };
      }

# Now print out the interpretation based on datatype

    CASE_TYPE:
      {

#   Datatypes 0 and 1 are null fields with a default 0 or 1 value, respectively

      ($field_datatype [$i] eq "0" || $field_datatype [$i] eq "1") && do
        { print "[This field has no data but takes on the default value ", $field_datatype [$i], "]"; };

#   Datatype BLOB is just a hex string with no interpretation. Do nothing...

#   Datatype FLOAT refers to a floating point number (8 bytes)

      ($field_datatype [$i] eq "FLOAT") && do
        { 
        printf ("    [%f]", big_endian ($bpos,$len,@record));
        };

#   Datatype INTEGER refers to an integer value (1, 2, 3, 4, 6, or 8 bytes)

      ($field_datatype [$i] eq "INTEGER") && do
        {
        $temp = big_endian ($bpos,$len,@record);
        printf ("    [%s]", commify ($temp));

# Special case alert! If size is 4 bytes and "date" or "time" is in the
# field label, this might be a timestamp....

        if ($field_datasize [$i] == 4 && ($field_label [$i] =~ m/date/i || $field_label [$i] =~m/time/i))
          {
          print "\n         [This field *might* be a date: ", scalar gmtime ($temp), " GMT]";
          }
        };

#   Datatypes NULL and RESERVED are null fields

      ($field_datatype [$i] eq "NULL" || $field_datatype [$i] eq "RESERVED") && do
        { print "[No data for this field]"; };

#   Datatype TEXT refers to a text string; just print the character (up to 40/line)

      ($field_datatype [$i] eq "TEXT") && do
        {
        for ($x = $bpos; $x < $bpos+$len; $x++)
          {
          if (($x-$bpos)%40 == 0)
            { print "\n         "; };
          $k = $record[$x];
          if ($k <= 0x1f || ($k >= 0x7f && $k <= 0x81)
             || ($k >= 0x8d && $k <= 90)
             || $k == 0x9d || $k == 0x9e)
                 { print "."; }
               else
                 { printf "%c", $k; }
          };
        };

      };

    print "\n";
    };

  }
  until (eof INFILE);

print "\n\n";

# Finish up!

close INFILE;

print "Cheers!\n\n";


# ********************************************************
# *****           SUBROUTINE BLOCKS                  *****

# ********************************************************

# ********************************************************
# big_endian
# ********************************************************

# Given an array name, starting position, and number of digits,
# calculate the decimal value using big endian (MSB first)

sub big_endian
{
my ($start,$n,@array) = @_;
my ($i, $sum);

$sum = $array[$start+$n-1];
for ($i=$n; $i>1; $i--)
  { $sum += $array[$start+$n-$i] * (2**(($i-1)*8)); }

return $sum;
}

# ********************************************************
# commify
# ********************************************************

# Routine from PerlFAQ5 -- add commas to large integers
# http://perldoc.perl.org/perlfaq5.html
  #How-can-I-output-my-numbers-with-commas-added?

sub commify

{
local $_  = shift;
1 while s/^([-+]?\d+)(\d{3})/$1,$2/;
return $_;
}

# ********************************************************
# header_type
# ********************************************************

# "Translate" the header value into a data type and size

sub header_type
{
my $value = $_[0];

CASE:
  {
  $value == 0 && do
    { return ("NULL", 0); };
  $value == 1 && do
    { return ("INTEGER", 1); };
  $value == 2 && do
    { return ("INTEGER", 2); };
  $value == 3 && do
    { return ("INTEGER", 3); };
  $value == 4 && do
    { return ("INTEGER", 4); };
  $value == 5 && do
    { return ("INTEGER", 6); };
  $value == 6 && do
    { return ("INTEGER", 8); };
  $value == 7 && do
    { return ("FLOAT", 8); };
  $value == 8 && do
    { return ("0", 0); };
  $value == 9 && do
    { return ("1", 0); };
  $value == 10 && do
    { return ("RESERVED", 0); };
  $value == 11 && do
    { return ("RESERVED", 0); };
  ($value >= 12 && $value%2 == 0) && do
    { return ("BLOB", ($value-12)/2); };
  ($value > 12 && $value%2 != 0) && do
    { return ("TEXT", ($value-13)/2); };
  };
}

# ********************************************************
# help_text
# ********************************************************

# Display the help file

sub help_text
{
print<< "EOT";
Program usage: sqlite_parser -i input_file -s { schema_file | ! }
               sqlite_parser {[-h] | [-v]}

 where: -i is the input file name
        -s is the schema file name *or* "!" to indicate no schema file
        -h prints this help file
        -v displays the program version number

If the -i or -s switches are missing, the program will ask for the
file names.

The input file must be a binary file containing the contents of one or
more SQLite database records.

The schema file, if it exists, must be a text file with the schema that
is associated with the database record. The individual labels in the
schema file should be separated by commas, e.g.:

     name,address,DOB

EOT

return;
}

# ********************************************************
# huffman_calc
# ********************************************************

# Calculate value of a field that might use Huffman coding
# The Huffman value on a field of $N bytes in length is
#  [SUM (i=1, $N-1) (byte[i]-128)*128^($N-i)] + byte[$N]

sub huffman_calc
{
my ($start, $N, @array) = @_;
my ($i, $sum);

if ($N == 1)
    { $sum = $array [$start]; }
  else
    {
    $sum = $array [$start+$N-1];
    for ($i = 1; $i <= $N-1; $i++)
      { $sum += ($array [$start+$i-1] - 128) * (128**($N-$i)); }
    }

return $sum;
}

# ********************************************************
# huffman_check
# ********************************************************

# Check value of a field that might use Huffman coding
# Look at the field byte by byte. If the first byte is <=0x80, then that
#  is the value of the field. If the first byte is >0x80, then continue
#  reading until a byte has a value <= 0x80.

sub huffman_check
{
my ($start, @array) = @_;
my ($N, $sum);

$N = 1;
while ($array [$start+$N-1] > 128)
  { $N++; }

$sum = huffman_calc ($start, $N, @array);

return ($N, $sum);
}

# ********************************************************
# list_hex_digits
# ********************************************************

# Given an array name, starting position, and number of digits, print
# out a string of hex digits in the format 0xAA-BB-CC...

sub list_hex_digits
{
my ($start,$n,@array) = @_;
my $i;

for ($i = $start; $i < $start+$n; $i++)
  {
  if ($i == $start)
      { print "0x"; }
    else
      { print "-"; }
  printf ("%02X", $array[$i]);
  }

return;
}

# ********************************************************
# parsecommandline
# ********************************************************

# Parse command line for any switches that are present. Query
# user for any missing information

# Return $state = 1 to indicate that the program should stop
# immediately (-h, -v, or unrecognized switch)

sub parsecommandline
{
my $state = 0;

# Parse command line switches ($ARGV array of length $#ARGV)

if ($#ARGV >= 0)
  { 
  for ($i = 0; $i <= $#ARGV; $i++)
    {
    PARMS:
      {
      $ARGV[$i] eq "-i" && do
         {
         $source = $ARGV[$i+1];
         $i++;
         last PARMS;
         };
      $ARGV[$i] eq "-s" && do
         {
         $schema = $ARGV[$i+1];
         $i++;
         last PARMS;
         };
      $ARGV[$i] eq "-v" && do
         {
         $state = 1;
         return $state;
         };
      $ARGV[$i] eq "-h" && do
         {
         help_text();
         $state = 1;
         return $state;
         };
      do
         {
         print "Invalid parameter \"$ARGV[$i]\".\n\n";
         print "Usage: sqlite_parser {[-i input_file] [-s schema_file | !] | [-h] | [-v]}\n\n";
         $state = 1;
         return $state;
         };
      };
    };
  }

# Prompt for file names, if not supplied

if ($source eq "")
  {
  print "Enter the input file name: ";
  chomp ($source = <STDIN>);
  print "\n";
  };

if ($schema eq "")
  {
  print "Enter the schema file name (or ! for null file): ";
  chomp ($schema = <STDIN>);
  print "\n";
  };

return $state;
}

# ********************************************************
# set_output
# ********************************************************

# Print output of the data bytes to show both hex and ASCII
# values.

sub set_output
{
my ($bpos,$n,@array) = @_;
my ($j, $k, $linemax);

# Format for a maximum of 16 items per line

$linemax = 16;

printf ("%03d: ", $bpos);
for ($j=0; $j<$n; $j++)
  {
  printf (" %02X", $array[$bpos+$j]);
  }
if ($n < $linemax)
  {
  for ($j=1; $j<=$linemax-$n; $j++)
    { print "   "; };
  }

print "   ";
for ($j=0; $j<$n; $j++)
  {
  $k = $array[$bpos+$j];

#   Print a dot (.) for unprintable characters

  if ($k <= 0x1f || ($k >= 0x7f && $k <= 0x9f))
      { print "."; }
    else
      { print chr($k); }
  }
print "\n";

return;
}

